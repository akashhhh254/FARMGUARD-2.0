import React, { useState, useEffect } from 'react';
import { 
  History, 
  ArrowLeft, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Camera, 
  Sparkles,
  ChevronRight,
  Plus
} from 'lucide-react';
import { FollowUpRecord, HealthScan, Language } from '../types';
import { fetchUserFollowUps, saveFollowUp } from '../utils/storage';

interface FollowUpSystemProps {
  userId: string;
  lang: Language;
  scans: HealthScan[];
  onOpenCropAI: () => void;
  onOpenAnimalAI: () => void;
  onBack: () => void;
}

export const FollowUpSystem: React.FC<FollowUpSystemProps> = ({
  userId,
  lang,
  scans,
  onOpenCropAI,
  onOpenAnimalAI,
  onBack
}) => {
  const [followUps, setFollowUps] = useState<FollowUpRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFollowUp, setSelectedFollowUp] = useState<FollowUpRecord | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const loaded = await fetchUserFollowUps(userId);
        if (loaded.length === 0 && scans.length > 0) {
          // Auto-seed a follow-up reminder from the most recent scan if empty
          const latest = scans[0];
          const autoScheduled: FollowUpRecord = {
            id: 'followup-' + latest.id,
            userId,
            originalScanId: latest.id,
            targetName: latest.targetName,
            type: latest.type,
            scheduledDate: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0],
            completed: false,
            originalCondition: latest.diseaseOrCondition,
            originalSeverity: latest.severity,
            statusChange: 'pending',
            notes: 'Re-check leaf margins 5 days after applying bio-fungicide or neem oil spray.'
          };
          setFollowUps([autoScheduled]);
        } else {
          setFollowUps(loaded);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [userId, scans]);

  const handleMarkFollowUpComplete = (item: FollowUpRecord, outcome: 'improved' | 'stable' | 'worsened') => {
    const updated = followUps.map((f) =>
      f.id === item.id
        ? {
            ...f,
            completed: true,
            statusChange: outcome,
            currentCondition: outcome === 'improved' ? 'Significant Recovery' : f.originalCondition,
            currentSeverity: outcome === 'improved' ? 'low' : outcome === 'worsened' ? 'critical' : f.originalSeverity
          }
        : f
    );
    setFollowUps(updated);
    setSelectedFollowUp(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-14">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold">
          AI Longitudinal Follow-Up
        </span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>🔬</span> AI Assessment Follow-Up & Progression
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Compare previous disease scan results against current plant/animal recovery to verify treatment effectiveness.
          </p>
        </div>

        {/* Follow up cards */}
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">Loading follow-up schedules...</div>
        ) : followUps.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto text-xl">
              🌱
            </div>
            <p className="text-sm font-semibold text-slate-800">No scheduled follow-ups yet</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Whenever you perform a crop or livestock scan, click <strong>"Schedule Follow-Up"</strong> to monitor recovery over time.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {followUps.map((item) => (
              <div
                key={item.id}
                className="p-5 rounded-2xl border border-slate-200 hover:border-emerald-300 bg-white transition-all space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{item.type === 'crop' ? '🌱' : '🐄'}</span>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 capitalize">
                        {item.targetName} Re-Inspection
                      </h4>
                      <p className="text-xs text-slate-400">Scheduled Date: {item.scheduledDate}</p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase ${
                      item.completed
                        ? item.statusChange === 'improved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.statusChange === 'worsened'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.completed ? `Outcome: ${item.statusChange}` : 'Pending Re-Check'}
                  </span>
                </div>

                {/* Compare Previous vs Current */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Previous condition box */}
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Initial Scan Condition
                    </span>
                    <p className="text-sm font-bold text-slate-900">{item.originalCondition}</p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-500">Initial Severity:</span>
                      <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-bold uppercase text-[10px]">
                        {item.originalSeverity}
                      </span>
                    </div>
                    {item.notes && <p className="text-xs text-slate-500 italic mt-1">"{item.notes}"</p>}
                  </div>

                  {/* Current / Follow-Up Box */}
                  <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-200 space-y-2">
                    <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                      Follow-Up Assessment
                    </span>

                    {item.completed ? (
                      <div className="space-y-1.5">
                        <p className="text-sm font-bold text-emerald-950">{item.currentCondition}</p>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-emerald-900">Current Status:</span>
                          <span
                            className={`font-bold capitalize ${
                              item.statusChange === 'improved' ? 'text-emerald-700' : 'text-slate-700'
                            }`}
                          >
                            {item.statusChange}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <p className="text-xs text-slate-600">
                          Ready to re-assess this {item.type}? Take a new photo to compare.
                        </p>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              if (item.type === 'crop') onOpenCropAI();
                              else onOpenAnimalAI();
                            }}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                          >
                            <Camera className="w-3.5 h-3.5" />
                            <span>Capture New Scan</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setSelectedFollowUp(item)}
                            className="px-3 py-1.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                          >
                            Record Outcome
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Outcome Recording Dialog */}
      {selectedFollowUp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Record Follow-Up Result for {selectedFollowUp.targetName}
            </h3>
            <p className="text-xs text-slate-500">
              How has the plant / animal condition changed since initial diagnosis?
            </p>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => handleMarkFollowUpComplete(selectedFollowUp, 'improved')}
                className="w-full p-3 rounded-2xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 font-semibold text-xs flex items-center justify-between cursor-pointer"
              >
                <span>🌱 Significant Improvement (New green shoots / symptoms cleared)</span>
                <TrendingUp className="w-4 h-4 text-emerald-600" />
              </button>
              <button
                type="button"
                onClick={() => handleMarkFollowUpComplete(selectedFollowUp, 'stable')}
                className="w-full p-3 rounded-2xl border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-950 font-semibold text-xs flex items-center justify-between cursor-pointer"
              >
                <span>⚖️ Stable / Controlled (No further spread)</span>
                <Minus className="w-4 h-4 text-blue-600" />
              </button>
              <button
                type="button"
                onClick={() => handleMarkFollowUpComplete(selectedFollowUp, 'worsened')}
                className="w-full p-3 rounded-2xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-950 font-semibold text-xs flex items-center justify-between cursor-pointer"
              >
                <span>⚠️ Worsened (Consider expert or veterinary consultation)</span>
                <TrendingDown className="w-4 h-4 text-red-600" />
              </button>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedFollowUp(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
