import React from 'react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/translations';
import { HealthScan, Language, WeatherData, MarketPrice, NavTab } from '../types';
import { 
  Sprout, 
  MapPin, 
  CloudSun, 
  Droplets, 
  Wind, 
  Bell, 
  History, 
  TrendingUp, 
  ChevronRight, 
  AlertCircle, 
  Activity, 
  Mic, 
  CalendarCheck, 
  BookOpen, 
  DollarSign, 
  ShieldCheck, 
  Sparkles,
  Search,
  RefreshCw,
  PhoneCall
} from 'lucide-react';

interface DashboardProps {
  onOpenCropAI: () => void;
  onOpenAnimalAI: () => void;
  onOpenProfile: () => void;
  onNavigate: (tab: NavTab) => void;
  scans: HealthScan[];
  onOpenScanDetail: (scan: HealthScan) => void;
  onOpenLocationModal: () => void;
  locationName: string;
  isGPS: boolean;
}

export const Dashboard: React.FC<DashboardProps> = ({
  onOpenCropAI,
  onOpenAnimalAI,
  onOpenProfile,
  onNavigate,
  scans,
  onOpenScanDetail,
  onOpenLocationModal,
  locationName,
  isGPS
}) => {
  const { userProfile } = useAuth();
  const lang: Language = userProfile?.preferredLanguage || 'en';
  const t = translations[lang] || translations.en;

  // Weather data
  const weather: WeatherData = {
    temp: 29,
    condition: 'Partly Cloudy & Humid',
    humidity: 78,
    rainfallRisk: '35% chance of light showers in 48h',
    windSpeed: 14,
    advisory: 'High relative humidity (>75%) increases risk of fungal leaf spot & blast. Delay foliar nitrogen spray until foliage dries.',
    locationName: locationName || 'Central Agricultural Zone',
    isLive: true
  };

  // APMC Mandi Market Rates
  const marketRates: MarketPrice[] = [
    { crop: 'Cotton (कपास)', market: 'Nagpur APMC', pricePerQuintal: 7350, trend: 'up', date: 'Today' },
    { crop: 'Soybean (सोयाबीन)', market: 'Amravati APMC', pricePerQuintal: 4620, trend: 'stable', date: 'Today' },
    { crop: 'Wheat (गेहूं)', market: 'Kalyan APMC', pricePerQuintal: 2580, trend: 'up', date: 'Yesterday' },
    { crop: 'Chili (मिर्च)', market: 'Nagpur Ganj', pricePerQuintal: 14200, trend: 'down', date: 'Today' }
  ];

  // Greeting based on time
  const hour = new Date().getHours();
  const greeting = hour < 12 ? t.goodMorning : hour < 18 ? t.goodAfternoon : t.goodEvening;
  const farmerName = userProfile?.displayName || 'Farmer';

  return (
    <div id="farmguard-dashboard" className="max-w-7xl mx-auto space-y-6 pb-12">
      
      {/* Top Welcome & Location Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">
              {greeting}, {farmerName}
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {t.farmMotto} • {userProfile?.farmName || 'My Farm'} ({userProfile?.farmSize || '5 Acres'})
          </p>
        </div>

        {/* Location toggle */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={onOpenLocationModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs text-slate-700 cursor-pointer transition-colors"
          >
            <MapPin className="w-3.5 h-3.5 text-emerald-600" />
            <span className="font-semibold truncate max-w-[150px]">{locationName}</span>
            {isGPS && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-1" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onNavigate('voice')}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Voice Assistant</span>
          </button>
        </div>
      </div>

      {/* PRIORITY 1 & 2: Crop Disease AI & Animal Health AI Dominant Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Crop Disease Early Detection AI */}
        <div 
          id="crop-health-card"
          onClick={onOpenCropAI}
          className="group relative overflow-hidden bg-gradient-to-br from-emerald-700 to-emerald-900 text-white p-6 sm:p-7 rounded-3xl shadow-sm hover:shadow-md transition-all cursor-pointer border border-emerald-600/40"
        >
          <div className="flex items-start justify-between">
            <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center text-3xl mb-4 group-hover:scale-105 transition-transform">
              🌱
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full backdrop-blur-xs">
              Primary AI Scanner
            </span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">{t.checkCropHealth}</h2>
          <p className="text-emerald-100 text-xs mt-1.5 max-w-md leading-relaxed">
            {t.checkCropSubtitle}
          </p>
          <div className="mt-6 flex items-center gap-2 text-xs font-bold text-white bg-white/20 hover:bg-white/30 self-start px-4 py-2.5 rounded-xl backdrop-blur-xs transition-colors">
            <span>Scan Leaf / Start Diagnosis</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        {/* Animal Health Screening AI */}
        <div 
          id="animal-health-card"
          onClick={onOpenAnimalAI}
          className="group relative overflow-hidden bg-gradient-to-br from-amber-700 to-amber-900 text-white p-6 sm:p-7 rounded-3xl shadow-sm hover:shadow-md transition-all cursor-pointer border border-amber-600/40"
        >
          <div className="flex items-start justify-between">
            <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center text-3xl mb-4 group-hover:scale-105 transition-transform">
              🐄
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-white/20 px-3 py-1 rounded-full backdrop-blur-xs">
              Veterinary Screener
            </span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">{t.checkAnimalHealth}</h2>
          <p className="text-amber-100 text-xs mt-1.5 max-w-md leading-relaxed">
            {t.checkAnimalSubtitle}
          </p>
          <div className="mt-6 flex items-center gap-2 text-xs font-bold text-white bg-white/20 hover:bg-white/30 self-start px-4 py-2.5 rounded-xl backdrop-blur-xs transition-colors">
            <span>Evaluate Symptoms / Voice Input</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

      </div>

      {/* QUICK FEATURE TILES (Sections 8, 9, 10, 11, 12, 13, 15, 17) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        
        <button
          type="button"
          onClick={() => onNavigate('overview')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Farm Health Overview</span>
            <span className="text-[10px] text-slate-500">Unified Score: 88/100</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('weather')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <CloudSun className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Weather & Water</span>
            <span className="text-[10px] text-slate-500">Irrigation Guidance</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('tasks')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <CalendarCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Task Planner</span>
            <span className="text-[10px] text-slate-500">Health Calendar</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('diary')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Digital Diary</span>
            <span className="text-[10px] text-slate-500">Logs & Voice Notes</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('expenses')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center group-hover:scale-110 transition-transform">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Expenses</span>
            <span className="text-[10px] text-slate-500">Inputs & Cost Tracking</span>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigate('knowledge')}
          className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition-all text-left flex flex-col justify-between h-32 cursor-pointer shadow-xs group"
        >
          <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-900 block leading-tight">Knowledge Hub</span>
            <span className="text-[10px] text-slate-500">Offline Care & Helplines</span>
          </div>
        </button>

      </div>

      {/* Unified Farm Health Overview, Weather & APMC Market Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Unified Farm Health Status */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-600" />
              {t.farmHealthOverview}
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('overview')}
              className="text-[11px] font-semibold text-emerald-700 hover:underline cursor-pointer"
            >
              Full Analytics →
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
                <span className="text-sm font-bold text-emerald-950">Overall: Healthy (88/100)</span>
              </div>
              <p className="text-xs text-emerald-800 mt-1">
                Crop disease pressure is low. Cotton leaf spot follow-up pending in 3 days.
              </p>
            </div>
            <span className="text-2xl">🟢</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Crop Health Condition</span>
              <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                Stable (3 fields clear)
              </span>
            </div>
            <div className="flex justify-between items-center py-1.5 border-b border-slate-100">
              <span className="text-slate-600">Livestock Risk Index</span>
              <span className="font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                Mastitis check advised
              </span>
            </div>
            <div className="flex justify-between items-center py-1.5">
              <span className="text-slate-600">Active Soil Moisture</span>
              <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                Adequate (62%)
              </span>
            </div>
          </div>
        </div>

        {/* Hyperlocal Weather & Agriculture Advisory */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <CloudSun className="w-4 h-4 text-amber-600" />
              {t.weatherIntel}
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('weather')}
              className="text-[11px] text-emerald-700 font-semibold hover:underline cursor-pointer"
            >
              Advisory & Rain →
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-extrabold text-slate-900">{weather.temp}°C</div>
              <div className="text-xs text-slate-500">{weather.condition}</div>
            </div>
            <div className="text-right space-y-1 text-xs text-slate-600">
              <div className="flex items-center gap-1 justify-end">
                <Droplets className="w-3.5 h-3.5 text-blue-500" />
                <span>Humidity: {weather.humidity}%</span>
              </div>
              <div className="flex items-center gap-1 justify-end">
                <Wind className="w-3.5 h-3.5 text-slate-400" />
                <span>Wind: {weather.windSpeed} km/h</span>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-blue-50/70 border border-blue-100 text-blue-900 text-xs">
            <span className="font-bold">Farm Advisory: </span>
            {weather.advisory}
          </div>
        </div>

        {/* Smart APMC Market Snapshot */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              {t.marketSnapshot}
            </h3>
            <span className="text-[11px] text-slate-400">APMC Mandi</span>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {marketRates.map((m, idx) => (
              <div key={idx} className="py-2 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-800">{m.crop}</div>
                  <div className="text-[11px] text-slate-400">{m.market}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-slate-900">₹{m.pricePerQuintal.toLocaleString()}/Q</div>
                  <span
                    className={`text-[10px] font-bold ${
                      m.trend === 'up' ? 'text-emerald-600' : m.trend === 'down' ? 'text-red-500' : 'text-slate-500'
                    }`}
                  >
                    {m.trend === 'up' ? '▲ +2.4%' : m.trend === 'down' ? '▼ -1.2%' : '■ Stable'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Recent Health Scans History & Smart Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Recent Scans (2 cols) */}
        <div className="lg:col-span-2 bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <History className="w-4 h-4 text-slate-600" />
              {t.recentScans} ({scans.length})
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="text-xs text-emerald-700 font-semibold hover:underline cursor-pointer"
            >
              View All History →
            </button>
          </div>

          {scans.length === 0 ? (
            <div className="text-center py-8 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <p className="text-xs text-slate-500">No crop or animal scans recorded yet.</p>
              <div className="mt-3 flex justify-center gap-3">
                <button
                  type="button"
                  onClick={onOpenCropAI}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer transition-colors"
                >
                  Scan Crop Leaf
                </button>
                <button
                  type="button"
                  onClick={onOpenAnimalAI}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold cursor-pointer transition-colors"
                >
                  Screen Livestock
                </button>
              </div>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {scans.slice(0, 4).map((scan) => (
                <div
                  key={scan.id}
                  onClick={() => onOpenScanDetail(scan)}
                  className="py-3 flex items-center justify-between hover:bg-slate-50 rounded-xl px-2 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">
                      {scan.type === 'crop' ? '🌱' : '🐄'}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 capitalize">
                        {scan.targetName}: {scan.diseaseOrCondition}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {new Date(scan.date).toLocaleDateString()} • {Math.round(scan.confidence * 100)}% Confidence
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase ${
                        scan.severity === 'critical' || scan.severity === 'high'
                          ? 'bg-red-100 text-red-800'
                          : scan.severity === 'moderate'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {scan.severity}
                    </span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Smart Alerts */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Bell className="w-4 h-4 text-red-600" />
              {t.activeAlerts}
            </h3>
            <span className="text-[11px] px-2 py-0.5 bg-red-100 text-red-700 font-bold rounded-full">
              2 Urgent
            </span>
          </div>

          <div className="space-y-2.5">
            <div className="p-3 rounded-2xl bg-red-50 border border-red-200 text-red-900 text-xs">
              <div className="font-bold flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                Regional Alert: Whitefly in Cotton
              </div>
              <p className="mt-1 text-red-800 text-[11px] leading-relaxed">
                Higher incidence of whitefly observed in neighboring talukas. Install yellow sticky traps (10/acre).
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
              <div className="font-bold flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                Vaccination Reminder
              </div>
              <p className="mt-1 text-amber-800 text-[11px] leading-relaxed">
                Pre-monsoon HS & FMD vaccine due for 2 cattle next week at local veterinary dispensary.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
