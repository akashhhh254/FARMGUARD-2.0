import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  PhoneCall, 
  ArrowLeft, 
  ShieldCheck, 
  Bug, 
  Sprout, 
  HeartHandshake, 
  AlertTriangle,
  FileCheck
} from 'lucide-react';
import { Language } from '../types';

interface KnowledgeHubProps {
  lang: Language;
  onBack: () => void;
}

interface Article {
  id: string;
  category: 'crops' | 'livestock' | 'first_aid' | 'beneficial' | 'soil' | 'vaccination';
  title: string;
  symptoms: string;
  management: string;
  urgentNotice?: string;
}

export const KnowledgeHub: React.FC<KnowledgeHubProps> = ({ lang, onBack }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const articles: Article[] = [
    {
      id: 'c1',
      category: 'crops',
      title: 'Cotton Leaf Curl Virus (CLCuV)',
      symptoms: 'Upward or downward curling of leaf margins, vein thickening, enations (small leaf-like growths) on leaf undersides, stunted growth.',
      management: 'Control whitefly (Bemisia tabaci) vectors with yellow sticky traps (6-8 traps/acre) and bio-pesticides like Neem Seed Kernel Extract (NSKE 5%). Remove and bury infected host weeds.',
      urgentNotice: 'Viral disease; chemical fungicides do not cure viruses. Focus strictly on vector management.'
    },
    {
      id: 'c2',
      category: 'crops',
      title: 'Tomato Early Blight (Alternaria solani)',
      symptoms: 'Dark brown concentric circular target-board spots on older leaves, lower leaves yellowing and dropping prematurely.',
      management: 'Ensure plant spacing for airflow. Avoid overhead sprinkler irrigation. Apply approved bio-agents (Trichoderma harzianum) or certified copper oxychloride as per local advisory.',
    },
    {
      id: 'c3',
      category: 'crops',
      title: 'Wheat Rust (Brown & Yellow Rust)',
      symptoms: 'Small yellow-orange or brown pustules arranged in linear stripes or scattered across leaf blades. Powder rubs off on fingers.',
      management: 'Grow resistant certified varieties. Inspect border rows during cool, humid mornings. Report sudden stripe rust sightings to local KVK.',
    },
    {
      id: 'l1',
      category: 'livestock',
      title: 'Foot and Mouth Disease (FMD) Screening',
      symptoms: 'High fever, intense salivation (drooling ropes of saliva), blisters/vesicles on tongue, lips, gums, and interdigital clefts of hooves. Severe lameness.',
      management: 'Isolate affected animals immediately. Wash oral lesions with mild 1% potassium permanganate or alum solution. Keep floor clean and dry.',
      urgentNotice: 'CRITICAL CONTAGION: Immediately inform government veterinary officer and restrict cattle movement.'
    },
    {
      id: 'l2',
      category: 'livestock',
      title: 'Bovine Mastitis (Udder Inflammation)',
      symptoms: 'Swollen, warm, hard, or tender udder quarter; discolored, clotty, or watery milk; reluctance to let calf suckle.',
      management: 'Practice teat dipping before and after milking using certified iodine solution. Complete dry cow therapy under veterinary guidance.',
      urgentNotice: 'Requires prompt antibiotic susceptibility treatment by licensed vet to prevent permanent quarter loss.'
    },
    {
      id: 'fa1',
      category: 'first_aid',
      title: 'Tympanitic Bloat in Cattle & Goats',
      symptoms: 'Rapid distension of left flank, laboured breathing, restlessness, kicking at belly.',
      management: 'Do not allow animal to lie down. Administer vegetable oil (peanut/mustard oil 500ml for adult cow) with turpentine oil (20-30ml) as emergency antifoaming under guidance.',
      urgentNotice: 'If severe asphyxiation occurs, emergency veterinary trocarization may be needed.'
    },
    {
      id: 'b1',
      category: 'beneficial',
      title: 'Ladybird Beetles & Chrysoperla (Farmer Allies)',
      symptoms: 'Identification: Red/orange spotted beetles and green lacewings.',
      management: 'Both adults and larvae voraciously consume aphids, jassids, and mealybugs (up to 50 aphids/day). Avoid indiscriminate broad-spectrum chemical sprays that kill these natural predators.',
    },
    {
      id: 's1',
      category: 'soil',
      title: 'Soil Organic Carbon (SOC) Improvement',
      symptoms: 'Compacted soil, poor water infiltration, rapid moisture loss.',
      management: 'Apply farmyard manure (FYM), compost, or crop residue mulching. Integrate pulse/legume green manuring crops (Dhaincha or Sunhemp) before flowering.',
    },
    {
      id: 'v1',
      category: 'vaccination',
      title: 'National Livestock Vaccination Timetable',
      symptoms: 'Preventative protocol for cattle, buffaloes, sheep, and goats.',
      management: 'FMD vaccine bi-annually (pre-monsoon & post-monsoon). Haemorrhagic Septicaemia (HS) and Black Quarter (BQ) pre-monsoon (May-June). Brucellosis calfhood vaccine at 4-8 months.',
      urgentNotice: 'Never vaccinate sick or heavily parasitized animals.'
    }
  ];

  const filtered = articles.filter((a) => {
    const matchesCat = selectedCategory === 'all' || a.category === selectedCategory;
    const matchesQuery =
      a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.symptoms.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.management.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-14">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold">
          Offline Knowledge Library
        </span>
      </div>

      {/* Emergency & KVK Contact Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-emerald-300 text-xs font-bold uppercase tracking-wider">
            <PhoneCall className="w-4 h-4" />
            <span>Emergency Ag & Veterinary Contacts</span>
          </div>
          <h3 className="text-xl font-bold tracking-tight">Kisan & Veterinary Helplines</h3>
          <p className="text-xs text-slate-300">
            Official government advisory numbers available across India (Toll-Free)
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <a
            href="tel:18001801551"
            className="px-4 py-2.5 rounded-2xl bg-white text-emerald-950 hover:bg-emerald-50 text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <span>📞 Kisan Call Centre: 1800-180-1551</span>
          </a>
          <a
            href="tel:1962"
            className="px-4 py-2.5 rounded-2xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <span>🚑 Animal Health Helpline: 1962</span>
          </a>
        </div>
      </div>

      {/* Main Knowledge Hub */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-600" />
              Agronomic Knowledge & Field Guide
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Available offline for quick in-field reference on crop pathologies, livestock diseases, and beneficial insects.
            </p>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search diseases, symptoms, pests..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 border-b border-slate-100 pb-3">
          {[
            { id: 'all', label: 'All Topics' },
            { id: 'crops', label: 'Crop Pathology' },
            { id: 'livestock', label: 'Livestock Care' },
            { id: 'first_aid', label: 'First-Aid' },
            { id: 'beneficial', label: 'Beneficial Insects' },
            { id: 'soil', label: 'Soil Health' },
            { id: 'vaccination', label: 'Vaccination Schedule' }
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Article Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-2xl border border-slate-200 hover:border-emerald-300 bg-white shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-sm font-bold text-slate-900">{item.title}</h4>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-bold uppercase">
                  {item.category}
                </span>
              </div>

              {item.urgentNotice && (
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>{item.urgentNotice}</span>
                </div>
              )}

              <div className="space-y-1.5 text-xs">
                <div>
                  <span className="font-bold text-slate-700">Symptoms & Indicators:</span>
                  <p className="text-slate-600 leading-relaxed mt-0.5">{item.symptoms}</p>
                </div>

                <div className="pt-1">
                  <span className="font-bold text-emerald-900">Recommended Management:</span>
                  <p className="text-slate-600 leading-relaxed mt-0.5">{item.management}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
