import React, { useState, useEffect } from 'react';
import { 
  IndianRupee, 
  Plus, 
  Calendar, 
  ArrowLeft, 
  TrendingDown, 
  TrendingUp, 
  PieChart, 
  X, 
  Check, 
  DollarSign 
} from 'lucide-react';
import { FarmExpense, Language } from '../types';
import { fetchUserExpenses, saveUserExpense } from '../utils/storage';

interface FarmExpensesProps {
  userId: string;
  lang: Language;
  onBack: () => void;
}

export const FarmExpenses: React.FC<FarmExpensesProps> = ({ userId, lang, onBack }) => {
  const [expenses, setExpenses] = useState<FarmExpense[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState<FarmExpense['category']>('fertilizer');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const loaded = await fetchUserExpenses(userId);
        setExpenses(loaded);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [userId]);

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!title.trim() || isNaN(numAmount) || numAmount <= 0) return;

    const expenseType = category === 'Crop sales' || category === 'Livestock sales' ? 'income' : 'expense';

    const created = await saveUserExpense(userId, {
      title: title.trim(),
      type: expenseType,
      amount: numAmount,
      category,
      date,
      notes: notes.trim()
    });

    setExpenses((prev) => [created, ...prev]);
    setShowAddModal(false);
    setTitle('');
    setAmount('');
    setNotes('');
  };

  const totalExpense = expenses.reduce((sum, item) => sum + item.amount, 0);

  const getCategoryColor = (cat: FarmExpense['category']) => {
    const map: Record<string, string> = {
      seeds: 'bg-emerald-100 text-emerald-800',
      fertilizers: 'bg-amber-100 text-amber-800',
      pesticides: 'bg-rose-100 text-rose-800',
      veterinary: 'bg-blue-100 text-blue-800',
      labor: 'bg-purple-100 text-purple-800',
      machinery: 'bg-orange-100 text-orange-800',
      irrigation: 'bg-cyan-100 text-cyan-800',
      harvesting: 'bg-yellow-100 text-yellow-800',
      transport: 'bg-indigo-100 text-indigo-800',
      other: 'bg-slate-100 text-slate-800'
    };
    return map[cat] || 'bg-slate-100 text-slate-800';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-14">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Record Expense</span>
        </button>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>💰</span> Farm Expense & Financial Ledger
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Track input investments in seeds, fertilizers, veterinary care, diesel, and farm labor.
          </p>
        </div>

        {/* Financial Summary Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Recorded Cost
            </span>
            <p className="text-2xl font-black text-slate-900 mt-1">
              ₹ {totalExpense.toLocaleString('en-IN')}
            </p>
            <span className="text-[11px] text-slate-400">Current Season</span>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
              Input Care Share
            </span>
            <p className="text-2xl font-black text-emerald-950 mt-1">
              ₹{' '}
              {expenses
                .filter((e) => ['fertilizers', 'pesticides', 'veterinary'].includes(e.category))
                .reduce((s, e) => s + e.amount, 0)
                .toLocaleString('en-IN')}
            </p>
            <span className="text-[11px] text-emerald-700">Health & Protection</span>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200">
            <span className="text-xs font-bold text-blue-800 uppercase tracking-wider">
              Entries Logged
            </span>
            <p className="text-2xl font-black text-blue-950 mt-1">{expenses.length}</p>
            <span className="text-[11px] text-blue-700">Verified Vouchers</span>
          </div>
        </div>

        {/* Expense List */}
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">Loading ledger...</div>
        ) : expenses.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <p className="text-sm font-semibold text-slate-700">No expenses recorded yet</p>
            <p className="text-xs text-slate-400">
              Keep track of farm purchase bills, spray costs, and wages.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {expenses.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 flex items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${getCategoryColor(
                        item.category
                      )}`}
                    >
                      {item.category}
                    </span>
                    <span className="font-bold text-slate-900">{item.title}</span>
                  </div>
                  {item.notes && <p className="text-slate-500 text-[11px]">{item.notes}</p>}
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {item.date}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-base font-black text-slate-900">
                    ₹ {item.amount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">Record Farm Expense</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Item / Expense Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bio-fertilizer bag, Cattle dewormer, Diesel"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Amount (₹) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    placeholder="e.g. 1450"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="seeds">Seeds</option>
                    <option value="fertilizers">Fertilizers</option>
                    <option value="pesticides">Pesticides / Bio-care</option>
                    <option value="veterinary">Veterinary / Medicine</option>
                    <option value="labor">Labor Wages</option>
                    <option value="machinery">Machinery / Diesel</option>
                    <option value="irrigation">Irrigation / Electricity</option>
                    <option value="harvesting">Harvesting</option>
                    <option value="transport">Transport</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Receipt / Notes
                </label>
                <input
                  type="text"
                  placeholder="Dealer name, voucher number, or quantity..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
