import React, { useState } from 'react';
import { X, ShieldCheck, FileText, PhoneCall, Bell, Globe, Check } from 'lucide-react';
import { Language } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSection?: 'privacy' | 'terms' | 'support' | 'settings';
  currentLang: Language;
  onUpdateLanguage: (lang: Language) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  initialSection = 'settings',
  currentLang,
  onUpdateLanguage
}) => {
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms' | 'support' | 'settings'>(initialSection);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [offlineSyncEnabled, setOfflineSyncEnabled] = useState(true);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-emerald-900 text-sm">FARM GUARD</span>
            <span className="text-slate-300">•</span>
            <span className="text-xs text-slate-500 capitalize">
              {activeTab === 'privacy' ? 'Privacy Policy' : activeTab === 'terms' ? 'Terms of Use' : activeTab === 'support' ? 'Help & Support' : 'App Settings'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 pt-2 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('settings')}
            className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
              activeTab === 'settings'
                ? 'border-emerald-600 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Settings
          </button>
          <button
            onClick={() => setActiveTab('support')}
            className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
              activeTab === 'support'
                ? 'border-emerald-600 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Contact / Support
          </button>
          <button
            onClick={() => setActiveTab('privacy')}
            className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
              activeTab === 'privacy'
                ? 'border-emerald-600 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Privacy Policy
          </button>
          <button
            onClick={() => setActiveTab('terms')}
            className={`pb-2.5 px-3 border-b-2 cursor-pointer transition-colors ${
              activeTab === 'terms'
                ? 'border-emerald-600 text-emerald-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Terms of Use
          </button>
        </div>

        {/* Tab content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700 flex-1">
          
          {activeTab === 'settings' && (
            <div className="space-y-5">
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Preferred Language</h4>
                <p className="text-slate-500 text-xs mb-3">Select the language for UI, voice assistant, and AI explanations.</p>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { code: 'en' as const, label: 'English' },
                    { code: 'hi' as const, label: 'हिन्दी (Hindi)' },
                    { code: 'mr' as const, label: 'मराठी (Marathi)' }
                  ].map((item) => (
                    <button
                      key={item.code}
                      onClick={() => onUpdateLanguage(item.code)}
                      className={`p-3 rounded-2xl border text-center font-medium cursor-pointer transition-all ${
                        currentLang === item.code
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold ring-1 ring-emerald-600'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 space-y-3">
                <h4 className="font-bold text-slate-900 text-sm">Farm Preferences</h4>
                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <div>
                    <p className="font-semibold text-slate-800 text-xs">Weather & Risk Notifications</p>
                    <p className="text-[11px] text-slate-500">Receive alerts on rain, pest warnings, and vaccination schedules</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationsEnabled}
                    onChange={(e) => setNotificationsEnabled(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <div>
                    <p className="font-semibold text-slate-800 text-xs">Offline Cache & Background Sync</p>
                    <p className="text-[11px] text-slate-500">Save farm logs locally and synchronize when internet returns</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={offlineSyncEnabled}
                    onChange={(e) => setOfflineSyncEnabled(e.target.checked)}
                    className="w-4 h-4 accent-emerald-600 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'support' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950">
                <h4 className="font-bold text-sm mb-1 flex items-center gap-2">
                  <PhoneCall className="w-4 h-4 text-emerald-700" />
                  Official Agricultural & Veterinary Helplines
                </h4>
                <p className="text-xs text-emerald-900">
                  Toll-free government advisories and emergency veterinary contacts:
                </p>
                <div className="mt-3 space-y-2 text-xs">
                  <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-emerald-200">
                    <span className="font-semibold">Kisan Call Centre (Toll-Free)</span>
                    <a href="tel:18001801551" className="font-bold text-emerald-700 hover:underline">1800-180-1551</a>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-emerald-200">
                    <span className="font-semibold">National Livestock Telemedicine Helpline</span>
                    <a href="tel:1962" className="font-bold text-emerald-700 hover:underline">1962 (Toll-Free)</a>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2.5 rounded-xl border border-emerald-200">
                    <span className="font-semibold">Farm Guard App Support Desk</span>
                    <span className="font-semibold text-slate-700">support@farmguard.ag</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <h5 className="font-bold text-slate-800">Krishi Vigyan Kendra (KVK) Network</h5>
                <p className="text-slate-600 text-xs leading-relaxed">
                  Farm Guard is designed to complement your local agronomists and KVK subject matter specialists.
                  For certified chemical prescriptions or severe epidemic notices, please contact your district KVK office.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-3 leading-relaxed text-slate-600">
              <h4 className="font-bold text-slate-900 text-sm">Farm Guard Privacy Commitment</h4>
              <p>
                Your privacy is vital. All farm records, crop disease photos, animal symptoms, financial logs, and location preferences are tied securely to your personal authenticated account.
              </p>
              <h5 className="font-bold text-slate-800">Data Ownership</h5>
              <p>
                You retain full ownership of your farm images and farm diaries. We do not sell or distribute individual farmer coordinates or harvest records to commercial advertisers.
              </p>
              <h5 className="font-bold text-slate-800">Location Usage</h5>
              <p>
                Your location is requested solely to fetch regional weather advisories and local pest forecasts. We do not perform real-time continuous GPS tracking.
              </p>
            </div>
          )}

          {activeTab === 'terms' && (
            <div className="space-y-3 leading-relaxed text-slate-600">
              <h4 className="font-bold text-slate-900 text-sm">Terms of Use & Decision Support Disclaimer</h4>
              <p>
                Farm Guard provides artificial intelligence screening, educational advisory, and early risk detection. It is designed to assist farmers in noticing potential leaf blights and animal discomfort early.
              </p>
              <h5 className="font-bold text-slate-800">Responsible Agricultural Decision Support</h5>
              <p>
                Farm Guard AI does not replace licensed veterinary surgeons or certified agronomy officers. Farmers must always consult certified package labels and local extension authorities before applying chemical fungicides, pesticides, or veterinary medications.
              </p>
              <h5 className="font-bold text-slate-800">Weather & Advisory Limitations</h5>
              <p>
                Weather alerts and rainfall forecasts are estimates based on meteorological services. Always use personal field observation before major sowing or spraying decisions.
              </p>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
