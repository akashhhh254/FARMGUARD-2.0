import React, { useState } from 'react';
import { 
  Sprout, 
  HeartHandshake, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowLeft, 
  TrendingUp, 
  Activity, 
  Calendar, 
  ShieldCheck,
  ChevronRight,
  FileDown
} from 'lucide-react';
import { HealthScan, Language } from '../types';
import { HealthTrendsChart } from './HealthTrendsChart';
import { ExportReportModal } from './ExportReportModal';

interface FarmOverviewProps {
  scans: HealthScan[];
  lang?: Language;
  onOpenCropAI: () => void;
  onOpenAnimalAI: () => void;
  onOpenTasks: () => void;
  onBack: () => void;
}

export const FarmOverview: React.FC<FarmOverviewProps> = ({
  scans,
  lang = 'en',
  onOpenCropAI,
  onOpenAnimalAI,
  onOpenTasks,
  onBack
}) => {
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const cropScans = scans.filter((s) => s.type === 'crop');
  const animalScans = scans.filter((s) => s.type === 'livestock');
  const highRiskScans = scans.filter((s) => s.severity === 'critical' || s.severity === 'high');
  const attentionScans = scans.filter((s) => s.severity === 'moderate');

  // Overall farm health determination
  const overallHealthStatus: 'healthy' | 'attention' | 'high_risk' =
    highRiskScans.length > 0
      ? 'high_risk'
      : attentionScans.length > 0
      ? 'attention'
      : 'healthy';

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-14">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsExportModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs cursor-pointer transition-colors"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export Summary PDF</span>
          </button>

          <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold hidden sm:inline-block">
            Unified Farm Intelligence
          </span>
        </div>
      </div>

      {/* Main Overall Farm Health Banner */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                Farm Health Overview
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 font-semibold uppercase">
                AI Estimated Indicator
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Holistic status combining crop disease scans, livestock screenings, and regional risks.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span
              className={`px-4 py-2 rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-xs ${
                overallHealthStatus === 'healthy'
                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  : overallHealthStatus === 'attention'
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : 'bg-red-100 text-red-900 border border-red-300'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  overallHealthStatus === 'healthy'
                    ? 'bg-emerald-600'
                    : overallHealthStatus === 'attention'
                    ? 'bg-amber-600'
                    : 'bg-red-600 animate-ping'
                }`}
              />
              {overallHealthStatus === 'healthy'
                ? 'Overall Farm Healthy'
                : overallHealthStatus === 'attention'
                ? 'Attention Needed'
                : 'High Risk Active'}
            </span>
          </div>
        </div>

        {/* 4-Metric High-Level Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
            <span className="text-xs font-bold text-emerald-900 uppercase">Crop Health</span>
            <p className="text-2xl font-black text-emerald-950 mt-1">
              {cropScans.filter((s) => s.severity === 'healthy' || s.severity === 'low').length} / {cropScans.length || 1}
            </p>
            <span className="text-[11px] text-emerald-700 font-medium">Fields Stable</span>
          </div>

          <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200">
            <span className="text-xs font-bold text-blue-900 uppercase">Livestock Health</span>
            <p className="text-2xl font-black text-blue-950 mt-1">
              {animalScans.filter((s) => s.severity === 'healthy' || s.severity === 'low').length} / {animalScans.length || 1}
            </p>
            <span className="text-[11px] text-blue-700 font-medium">Screenings Normal</span>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200">
            <span className="text-xs font-bold text-amber-900 uppercase">Active Risks</span>
            <p className="text-2xl font-black text-amber-950 mt-1">
              {highRiskScans.length + attentionScans.length}
            </p>
            <span className="text-[11px] text-amber-700 font-medium">Alerts Logged</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-xs font-bold text-slate-700 uppercase">Total AI Scans</span>
            <p className="text-2xl font-black text-slate-900 mt-1">{scans.length}</p>
            <span className="text-[11px] text-slate-500 font-medium">Saved Records</span>
          </div>
        </div>
      </div>

      {/* Recharts Health Trends Visualization */}
      <HealthTrendsChart scans={scans} lang={lang} />

      {/* Sections: Crop vs Livestock Detailed Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        
        {/* Crop Health Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-xl">
                🌱
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Crop Health Monitor</h3>
                <p className="text-xs text-slate-500">{cropScans.length} assessments completed</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenCropAI}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              + New Scan
            </button>
          </div>

          <div className="space-y-2">
            {cropScans.slice(0, 3).map((scan) => (
              <div
                key={scan.id}
                className="p-3 rounded-2xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-900 capitalize">{scan.targetName}</span>
                  <p className="text-slate-500 text-[11px]">{scan.diseaseOrCondition}</p>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                    scan.severity === 'critical' || scan.severity === 'high'
                      ? 'bg-red-100 text-red-800'
                      : scan.severity === 'moderate'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {scan.severity}
                </span>
              </div>
            ))}
            {cropScans.length === 0 && (
              <p className="text-xs text-slate-400 py-3 text-center">No crop assessments recorded yet.</p>
            )}
          </div>
        </div>

        {/* Livestock Health Card */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center text-xl">
                🐄
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Livestock Risk Monitor</h3>
                <p className="text-xs text-slate-500">{animalScans.length} screenings completed</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenAnimalAI}
              className="text-xs font-bold text-blue-700 hover:text-blue-800 cursor-pointer"
            >
              + New Screening
            </button>
          </div>

          <div className="space-y-2">
            {animalScans.slice(0, 3).map((scan) => (
              <div
                key={scan.id}
                className="p-3 rounded-2xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
              >
                <div>
                  <span className="font-bold text-slate-900 capitalize">{scan.targetName}</span>
                  <p className="text-slate-500 text-[11px]">{scan.diseaseOrCondition}</p>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                    scan.severity === 'critical' || scan.severity === 'high'
                      ? 'bg-red-100 text-red-800'
                      : scan.severity === 'moderate'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {scan.severity}
                </span>
              </div>
            ))}
            {animalScans.length === 0 && (
              <p className="text-xs text-slate-400 py-3 text-center">No animal health screenings recorded yet.</p>
            )}
          </div>
        </div>

      </div>

      {/* Preventive Actions & Upcoming Care Plan */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            Seasonal Preventive Recommendations
          </h3>
          <button
            type="button"
            onClick={onOpenTasks}
            className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
          >
            Manage Farm Tasks →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800">1. Whitefly Vector Scouting</span>
            <p className="text-slate-500 text-[11px]">
              Inspect 10 plants per acre across leaf undersides to detect early leaf curl vectors.
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800">2. Deworming Schedule</span>
            <p className="text-slate-500 text-[11px]">
              Ensure calves and small ruminants receive broad-spectrum anthelmintic doses.
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
            <span className="font-bold text-slate-800">3. Channel Clearing</span>
            <p className="text-slate-500 text-[11px]">
              Drain furrow low-spots ahead of forecasted scattered rains to avoid root rot.
            </p>
          </div>
        </div>
      </div>

      {/* Export Summary PDF Modal */}
      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        scans={scans}
      />
    </div>
  );
};
