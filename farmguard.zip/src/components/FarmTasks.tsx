import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Plus, 
  Calendar as CalendarIcon, 
  ArrowLeft, 
  Filter, 
  Clock, 
  Check, 
  X,
  AlertCircle,
  Sprout,
  HeartPulse
} from 'lucide-react';
import { FarmTask, Language } from '../types';
import { 
  fetchUserTasks, 
  saveUserTask, 
  toggleUserTask, 
  DEFAULT_TASKS 
} from '../utils/storage';

interface FarmTasksProps {
  userId: string;
  lang: Language;
  onBack: () => void;
}

export const FarmTasks: React.FC<FarmTasksProps> = ({ userId, lang, onBack }) => {
  const [tasks, setTasks] = useState<FarmTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterView, setFilterView] = useState<'all' | 'today' | 'upcoming' | 'completed'>('today');
  const [showAddModal, setShowAddModal] = useState(false);

  // New task form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<FarmTask['category']>('inspection');
  const [newDueDate, setNewDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [newNotes, setNewNotes] = useState('');

  useEffect(() => {
    async function loadTasks() {
      try {
        const loaded = await fetchUserTasks(userId);
        setTasks(loaded);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadTasks();
  }, [userId]);

  const handleToggleTask = async (taskId: string, currentCompleted: boolean) => {
    const updated = !currentCompleted;
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, completed: updated } : t)));
    await toggleUserTask(userId, taskId, updated);
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created = await saveUserTask(userId, {
      title: newTitle.trim(),
      category: newCategory,
      dueDate: newDueDate,
      completed: false,
      priority: newPriority,
      notes: newNotes.trim()
    });

    setTasks((prev) => [created, ...prev]);
    setShowAddModal(false);
    setNewTitle('');
    setNewNotes('');
  };

  const todayStr = new Date().toISOString().split('T')[0];

  const filteredTasks = tasks.filter((t) => {
    if (filterView === 'completed') return t.completed;
    if (filterView === 'today') return !t.completed && t.dueDate <= todayStr;
    if (filterView === 'upcoming') return !t.completed && t.dueDate > todayStr;
    return true;
  });

  const getCategoryIcon = (cat: FarmTask['category']) => {
    switch (cat) {
      case 'inspection':
        return '🔍';
      case 'irrigation':
        return '💧';
      case 'fertilizer':
        return '🌱';
      case 'vaccination':
        return '💉';
      case 'harvest':
        return '🌾';
      default:
        return '📋';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-14">
      {/* Top navigation */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Farm Task</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>📅</span> Farm Task Planner & Health Calendar
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Organize daily crop scouting, irrigation cycles, vaccination boosters, and follow-up activities.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap gap-2 border-b border-slate-100 pb-4">
          {[
            { id: 'today', label: "Today's Tasks" },
            { id: 'upcoming', label: 'Upcoming Tasks' },
            { id: 'completed', label: 'Completed' },
            { id: 'all', label: 'All Tasks' }
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterView(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                filterView === tab.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Task List */}
        {loading ? (
          <div className="py-10 text-center text-xs text-slate-400">Loading farm schedule...</div>
        ) : filteredTasks.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto text-xl">
              ✓
            </div>
            <p className="text-sm font-semibold text-slate-800">No tasks in this view</p>
            <p className="text-xs text-slate-400">
              {filterView === 'today'
                ? "All caught up for today! Add a new task if you're planning more field work."
                : 'No matching scheduled tasks found.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                  task.completed
                    ? 'bg-slate-50 border-slate-200 opacity-60'
                    : 'bg-white border-slate-200 hover:border-emerald-300 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    type="button"
                    onClick={() => handleToggleTask(task.id, task.completed)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-600 cursor-pointer"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 hover:text-emerald-500" />
                    )}
                  </button>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm">{getCategoryIcon(task.category)}</span>
                      <h4
                        className={`text-sm font-bold ${
                          task.completed ? 'line-through text-slate-500' : 'text-slate-900'
                        }`}
                      >
                        {task.title}
                      </h4>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                          task.priority === 'high'
                            ? 'bg-red-100 text-red-800'
                            : task.priority === 'medium'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {task.priority || 'Normal'}
                      </span>
                    </div>

                    {task.notes && (
                      <p className="text-xs text-slate-600">{task.notes}</p>
                    )}

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                      <span className="flex items-center gap-1">
                        <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                        Due: {task.dueDate}
                      </span>
                      <span className="capitalize text-emerald-700 font-medium">
                        Category: {task.category}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">Create New Farm Task</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Task Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apply bio-fungicide in Cotton field"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="inspection">Crop Inspection</option>
                    <option value="irrigation">Irrigation</option>
                    <option value="fertilizer">Fertilizer</option>
                    <option value="vaccination">Vaccination / Vet</option>
                    <option value="harvest">Harvesting</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Priority
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Notes / Instructions
                </label>
                <textarea
                  rows={2}
                  placeholder="Additional field or dosage details..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold"
                >
                  Save Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
