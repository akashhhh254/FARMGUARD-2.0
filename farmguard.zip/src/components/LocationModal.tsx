import React, { useState } from 'react';
import { MapPin, Navigation, X, Check, AlertCircle, Shield } from 'lucide-react';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocationName: string;
  onUpdateLocation: (locationName: string, isGPS: boolean, coords?: { lat: number; lng: number }) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  currentLocationName,
  onUpdateLocation
}) => {
  const [manualVillage, setManualVillage] = useState('');
  const [manualDistrict, setManualDistrict] = useState('');
  const [manualState, setManualState] = useState('Maharashtra');
  const [isLocating, setIsLocating] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleUseGPS = () => {
    if (!navigator.geolocation) {
      setErrorMsg('Geolocation is not supported by your device browser. Please enter your location manually.');
      return;
    }

    setIsLocating(true);
    setErrorMsg(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        // We do NOT expose exact coordinates publicly; we present a localized region label
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        const label = `Agro Zone (${lat.toFixed(2)}°N, ${lng.toFixed(2)}°E)`;
        onUpdateLocation(label, true, { lat, lng });
        onClose();
      },
      (err) => {
        setIsLocating(false);
        setErrorMsg(
          'Location access was not granted or timed out. You can enter your village and district manually below.'
        );
      },
      { timeout: 10000, enableHighAccuracy: false }
    );
  };

  const handleSaveManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualDistrict.trim()) {
      setErrorMsg('Please enter at least your District or Tehsil.');
      return;
    }
    const label = manualVillage.trim()
      ? `${manualVillage.trim()}, ${manualDistrict.trim()}`
      : `${manualDistrict.trim()}, ${manualState}`;
    onUpdateLocation(label, false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Farm Location Settings</h3>
              <p className="text-xs text-slate-500">For weather, disease warnings & local advisory</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          
          {/* Transparent explanation banner */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-emerald-700 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold">Why Farm Guard needs your location:</p>
              <ul className="list-disc list-inside space-y-0.5 text-emerald-900 text-[11px]">
                <li>Deliver hyper-local weather alerts & rain warnings</li>
                <li>Monitor regional pest outbreaks in your taluka</li>
                <li>Provide nearby Krishi Vigyan Kendra & veterinary help</li>
              </ul>
              <p className="text-[10px] text-emerald-800 pt-0.5">
                We do not continuously track you or expose your exact coordinates publicly.
              </p>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Option 1: Live GPS */}
          <div>
            <button
              type="button"
              disabled={isLocating}
              onClick={handleUseGPS}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer disabled:opacity-50"
            >
              <Navigation className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
              <span>{isLocating ? 'Detecting Agro-Zone...' : 'Use Current Location'}</span>
            </button>
          </div>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-3 text-[11px] font-semibold uppercase text-slate-400">
              Or Enter Manually
            </span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          {/* Option 2: Enter location manually */}
          <form onSubmit={handleSaveManual} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Village / Town Name
              </label>
              <input
                type="text"
                placeholder="e.g. Katol, Sawangi, Baramati"
                value={manualVillage}
                onChange={(e) => setManualVillage(e.target.value)}
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  District *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Nagpur, Pune, Nashik"
                  value={manualDistrict}
                  onChange={(e) => setManualDistrict(e.target.value)}
                  required
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  State
                </label>
                <input
                  type="text"
                  value={manualState}
                  onChange={(e) => setManualState(e.target.value)}
                  className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Save Manual Location</span>
            </button>
          </form>

        </div>
      </div>
    </div>
  );
};
