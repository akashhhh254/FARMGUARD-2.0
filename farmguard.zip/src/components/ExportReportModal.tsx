import React, { useState } from 'react';
import { 
  X, 
  FileDown, 
  Printer, 
  Share2, 
  Check, 
  FileText, 
  User, 
  Building2, 
  MapPin, 
  AlertTriangle, 
  CheckCircle2, 
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { HealthScan } from '../types';
import { useAuth } from '../context/AuthContext';
import { generateHealthSummaryPDF, ReportOptions } from '../utils/pdfExport';

interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  scans: HealthScan[];
}

export const ExportReportModal: React.FC<ExportReportModalProps> = ({
  isOpen,
  onClose,
  scans
}) => {
  const { userProfile, user } = useAuth();
  
  const [consultantName, setConsultantName] = useState('Krishi Vigyan Kendra (KVK) Agronomist / Veterinary Officer');
  const [filterType, setFilterType] = useState<'all' | 'crop' | 'livestock' | 'high_risk'>('all');
  const [farmerNotes, setFarmerNotes] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  if (!isOpen) return null;

  const filteredScans = scans.filter((s) => {
    if (filterType === 'crop') return s.type === 'crop';
    if (filterType === 'livestock') return s.type === 'livestock';
    if (filterType === 'high_risk') return s.severity === 'critical' || s.severity === 'high';
    return true;
  });

  const highRiskCount = filteredScans.filter((s) => s.severity === 'critical' || s.severity === 'high').length;
  const moderateCount = filteredScans.filter((s) => s.severity === 'moderate').length;
  const healthyCount = filteredScans.filter((s) => s.severity === 'healthy' || s.severity === 'low').length;

  const handleDownloadPDF = () => {
    setIsGenerating(true);
    try {
      const options: ReportOptions = {
        farmerName: userProfile?.displayName || user?.email?.split('@')[0] || 'Farmer',
        farmName: userProfile?.farmName || 'Primary Farm Holding',
        location: userProfile?.district 
          ? `${userProfile.village ? userProfile.village + ', ' : ''}${userProfile.district}, ${userProfile.state || 'India'}`
          : 'Nagpur Region, Maharashtra',
        consultantName: consultantName.trim() || 'Agricultural Extension Consultant',
        notes: farmerNotes.trim(),
        filterType
      };

      generateHealthSummaryPDF(scans, userProfile, options);
    } catch (err) {
      console.error('Failed to export PDF:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyShareSummary = () => {
    const farmerName = userProfile?.displayName || 'Farmer';
    const location = userProfile?.district ? `${userProfile.district}, ${userProfile.state || ''}` : 'Farm Holding';
    const textSummary = `📋 *FarmGuard Health Report Summary*\n` +
      `👤 Farmer: ${farmerName}\n` +
      `📍 Location: ${location}\n` +
      `📅 Date: ${new Date().toLocaleDateString('en-IN')}\n` +
      `📊 Total Records: ${filteredScans.length} (Critical: ${highRiskCount}, Moderate: ${moderateCount}, Stable: ${healthyCount})\n\n` +
      `*Latest Findings:*\n` +
      filteredScans.slice(0, 4).map((s, i) => `${i + 1}. [${s.type.toUpperCase()}] ${s.targetName}: ${s.diseaseOrCondition} (${s.severity.toUpperCase()})`).join('\n') +
      (farmerNotes ? `\n\n*Farmer Note for Consultant:*\n"${farmerNotes}"` : '') +
      `\n\nGenerated via FarmGuard AI Agricultural Support`;

    navigator.clipboard.writeText(textSummary);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 3000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col my-auto overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <FileDown className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Export Scan History Report (PDF)
              </h3>
              <p className="text-xs text-slate-500">
                Generate an official agricultural health summary for consultants, KVK officers, or farm records.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          
          {/* Configuration Form */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Report Configuration
            </h4>

            {/* Scope Filter */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Filter Scope</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'all', label: `All Scans (${scans.length})` },
                  { id: 'crop', label: `Crops (${scans.filter(s => s.type === 'crop').length})` },
                  { id: 'livestock', label: `Livestock (${scans.filter(s => s.type === 'livestock').length})` },
                  { id: 'high_risk', label: `High Risk (${scans.filter(s => s.severity === 'critical' || s.severity === 'high').length})` }
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setFilterType(t.id as any)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer text-center ${
                      filterType === t.id
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Consultant / Recipient Name */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">
                Agricultural Consultant / Veterinary Officer Name (Optional)
              </label>
              <input
                type="text"
                value={consultantName}
                onChange={(e) => setConsultantName(e.target.value)}
                placeholder="e.g. Dr. Deshmukh / District Agricultural Extension Officer"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-emerald-600 bg-white"
              />
            </div>

            {/* Notes / Questions for Consultant */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">
                Specific Inquiries or Field Observations for Consultant (Optional)
              </label>
              <textarea
                value={farmerNotes}
                onChange={(e) => setFarmerNotes(e.target.value)}
                rows={2}
                placeholder="e.g. Yellowing on lower leaves observed after continuous rain. Please advise on bio-fungicide dosing."
                className="w-full text-xs px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-emerald-600 bg-white"
              />
            </div>
          </div>

          {/* Document Preview Card */}
          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-600" />
                Live PDF Document Preview
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold">
                A4 Official Format
              </span>
            </div>

            {/* Header Mockup */}
            <div className="bg-white rounded-xl p-3 border border-slate-200 shadow-xs space-y-2 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-extrabold text-slate-900 text-sm">FARM GUARD HEALTH REPORT</span>
                  <p className="text-[11px] text-slate-500">
                    {userProfile?.displayName || user?.email?.split('@')[0] || 'Farmer'} • {userProfile?.farmName || 'Farm Holding'}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {userProfile?.district ? `${userProfile.district}, ${userProfile.state || ''}` : 'Nagpur Region, Maharashtra'}
                  </p>
                </div>
                <div className="text-right text-[10px] text-slate-500">
                  <div>Date: <strong>{new Date().toLocaleDateString('en-IN')}</strong></div>
                  <div>Consultant: <strong>{consultantName.slice(0, 28)}...</strong></div>
                </div>
              </div>

              {/* Mini Stats Grid */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100 text-center">
                  <div className="text-[10px] text-slate-500">Scans</div>
                  <div className="font-bold text-slate-900">{filteredScans.length}</div>
                </div>
                <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-100 text-center">
                  <div className="text-[10px] text-emerald-700">Stable</div>
                  <div className="font-bold text-emerald-900">{healthyCount}</div>
                </div>
                <div className="p-1.5 rounded-lg bg-amber-50 border border-amber-100 text-center">
                  <div className="text-[10px] text-amber-700">Moderate</div>
                  <div className="font-bold text-amber-900">{moderateCount}</div>
                </div>
                <div className="p-1.5 rounded-lg bg-red-50 border border-red-100 text-center">
                  <div className="text-[10px] text-red-700">Critical</div>
                  <div className="font-bold text-red-900">{highRiskCount}</div>
                </div>
              </div>

              {/* Table Rows Preview */}
              <div className="space-y-1 pt-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Included Records Preview:</div>
                {filteredScans.slice(0, 3).map((scan) => (
                  <div
                    key={scan.id}
                    className="p-2 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between text-[11px]"
                  >
                    <div>
                      <span className="font-semibold text-slate-800">
                        {scan.type === 'crop' ? '🌱' : '🐄'} {scan.targetName}:
                      </span>{' '}
                      <span className="text-slate-600">{scan.diseaseOrCondition}</span>
                    </div>
                    <span
                      className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        scan.severity === 'critical' || scan.severity === 'high'
                          ? 'bg-red-100 text-red-800'
                          : scan.severity === 'moderate'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {scan.severity}
                    </span>
                  </div>
                ))}
                {filteredScans.length > 3 && (
                  <p className="text-[10px] text-slate-400 italic text-center">
                    + {filteredScans.length - 3} more records included in full PDF table.
                  </p>
                )}
                {filteredScans.length === 0 && (
                  <p className="text-[11px] text-slate-400 py-2 text-center">
                    No scans in selected filter. Run scans or switch filter to 'All Scans'.
                  </p>
                )}
              </div>

              {/* Verification & Stamp Area */}
              <div className="border-t border-dashed border-slate-200 pt-2 text-[10px] text-slate-400 flex justify-between">
                <span>Includes Consultant Sign-off & Stamp Line</span>
                <span>Govt Kisan Helpline 1800-180-1551</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
          
          <button
            type="button"
            onClick={handleCopyShareSummary}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copiedShare ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Copied to Clipboard!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 text-slate-500" />
                <span>Copy WhatsApp / SMS Text</span>
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Print via browser dialog"
            >
              <Printer className="w-4 h-4 text-slate-500" />
              <span>Print</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPDF}
              disabled={isGenerating}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
            >
              <FileDown className="w-4 h-4" />
              <span>{isGenerating ? 'Generating PDF...' : 'Download PDF Report'}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
