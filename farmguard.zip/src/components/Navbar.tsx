import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { translations } from '../utils/translations';
import { Language, NavTab } from '../types';
import { 
  Sprout, 
  User, 
  LogOut, 
  Globe, 
  Activity, 
  FileText, 
  Wifi, 
  WifiOff, 
  Calendar,
  Sparkles,
  Mic,
  BookOpen,
  DollarSign,
  CloudSun,
  Menu,
  X,
  History,
  ShieldCheck,
  PhoneCall
} from 'lucide-react';

interface NavbarProps {
  currentTab: NavTab;
  setCurrentTab: (tab: NavTab) => void;
  isOnline: boolean;
  onOpenVoice: () => void;
  onOpenSettings: (tab?: 'settings' | 'support' | 'privacy' | 'terms') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  currentTab, 
  setCurrentTab, 
  isOnline,
  onOpenVoice,
  onOpenSettings
}) => {
  const { userProfile, signOut, updateUserLanguage } = useAuth();
  const lang: Language = userProfile?.preferredLanguage || 'en';
  const t = translations[lang] || translations.en;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateUserLanguage(e.target.value as Language);
  };

  const navItems: { id: NavTab; label: string; icon?: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'crop', label: 'Crop AI', icon: '🌱' },
    { id: 'animal', label: 'Livestock AI', icon: '🐄' },
    { id: 'overview', label: 'Farm Health' },
    { id: 'weather', label: 'Weather & Water' },
    { id: 'tasks', label: 'Tasks' },
    { id: 'diary', label: 'Diary' },
    { id: 'history', label: 'History' },
    { id: 'knowledge', label: 'Knowledge' }
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand */}
          <div 
            onClick={() => {
              setCurrentTab('dashboard');
              setMobileMenuOpen(false);
            }} 
            className="flex items-center gap-3 cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <Sprout className="w-6 h-6" />
            </div>
            <div>
              <span className="text-lg font-black tracking-tight text-emerald-950">FARM GUARD</span>
              <p className="text-[10px] text-slate-500 hidden sm:block">AI Early Detection & Health Platform</p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1 text-xs font-semibold">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setCurrentTab(item.id)}
                className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                  currentTab === item.id
                    ? 'bg-emerald-50 text-emerald-900 font-bold border border-emerald-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {item.icon && <span>{item.icon}</span>}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* Right Action Menu */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Voice Assistant Quick Mic button */}
            <button
              id="navbar-voice-btn"
              type="button"
              onClick={onOpenVoice}
              title="Voice Assistant"
              className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition-colors flex items-center gap-1.5 text-xs font-bold border border-emerald-200 cursor-pointer"
            >
              <Mic className="w-4 h-4 text-emerald-600" />
              <span className="hidden sm:inline">Voice AI</span>
            </button>

            {/* Online / Offline status */}
            <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-500">
              {isOnline ? (
                <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <Wifi className="w-3 h-3 text-emerald-600" />
                  Online
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                  <WifiOff className="w-3 h-3 text-slate-500" />
                  Offline-First
                </span>
              )}
            </div>

            {/* Language Selector */}
            <div className="flex items-center gap-1 bg-slate-50 px-2 py-1 rounded-xl border border-slate-200">
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <select
                id="language-select-dropdown"
                value={lang}
                onChange={handleLanguageChange}
                className="bg-transparent text-xs font-semibold text-slate-700 outline-none cursor-pointer"
              >
                <option value="en">EN</option>
                <option value="hi">हिन्दी</option>
                <option value="mr">मराठी</option>
              </select>
            </div>

            {/* Farmer Profile Button */}
            <button
              id="profile-nav-btn"
              type="button"
              onClick={() => setCurrentTab('profile')}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center overflow-hidden">
                {userProfile?.photoURL ? (
                  <img src={userProfile.photoURL} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  userProfile?.displayName?.charAt(0) || 'F'
                )}
              </div>
              <span className="text-xs font-semibold text-slate-800 hidden xl:block truncate max-w-[90px]">
                {userProfile?.displayName?.split(' ')[0] || 'Profile'}
              </span>
            </button>

            {/* Mobile menu toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-1 shadow-lg animate-in slide-in-from-top-2 duration-150">
          <div className="grid grid-cols-2 gap-1.5 pb-2 border-b border-slate-100">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setCurrentTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`p-2.5 rounded-xl text-xs font-semibold text-left flex items-center gap-2 ${
                  currentTab === item.id
                    ? 'bg-emerald-50 text-emerald-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {item.icon && <span>{item.icon}</span>}
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 flex items-center justify-between text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                onOpenSettings('support');
                setMobileMenuOpen(false);
              }}
              className="text-slate-600 hover:text-slate-900 p-1.5"
            >
              Helplines & Support
            </button>
            <button
              type="button"
              onClick={() => {
                signOut();
                setMobileMenuOpen(false);
              }}
              className="text-red-600 hover:text-red-700 p-1.5"
            >
              Sign Out
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
