import React, { useState, useRef } from 'react';
import { analyzeLivestockHealth } from '../services/aiService';
import { HealthScan, Language } from '../types';
import { 
  Camera, 
  Sparkles, 
  Mic, 
  MicOff, 
  ArrowLeft, 
  RefreshCw, 
  ShieldAlert, 
  CheckCircle2, 
  HeartHandshake,
  AlertTriangle
} from 'lucide-react';

interface AnimalHealthProps {
  lang: Language;
  onScanComplete: (scan: HealthScan) => void;
  onBack: () => void;
}

const LIVESTOCK_TYPES = [
  { id: 'cow', label: 'Cow (गाय)', icon: '🐄' },
  { id: 'buffalo', label: 'Buffalo (भैंस / म्हैस)', icon: '🐃' },
  { id: 'goat', label: 'Goat (बकरी / शेळी)', icon: '🐐' },
  { id: 'sheep', label: 'Sheep (भेड़ / मेंढी)', icon: '🐑' },
  { id: 'poultry', label: 'Poultry (मुर्गी / कुक्कुट)', icon: '🐔' },
  { id: 'other', label: 'Other Livestock', icon: '🐾' }
];

const COMMON_SYMPTOMS = [
  'High fever / warm ears',
  'Loss of appetite (खाना छोड़ना)',
  'Cough or abnormal breathing',
  'Nasal discharge / runny nose',
  'Severe diarrhea',
  'Udder swelling / clotted milk',
  'Skin lesions or blisters',
  'Difficulty walking / limping',
  'Lethargy / dullness',
  'Abnormal behavior or tremor'
];

export const AnimalHealth: React.FC<AnimalHealthProps> = ({ lang, onScanComplete, onBack }) => {
  const [selectedAnimal, setSelectedAnimal] = useState('cow');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [voiceText, setVoiceText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HealthScan | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleSymptom = (sym: string) => {
    if (selectedSymptoms.includes(sym)) {
      setSelectedSymptoms(selectedSymptoms.filter((s) => s !== sym));
    } else {
      setSelectedSymptoms([...selectedSymptoms, sym]);
    }
  };

  // Voice recognition support (Web Speech API)
  const handleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. You can select symptoms using buttons below.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setVoiceText(transcript);
        // Automatically match symptoms from voice
        const lower = transcript.toLowerCase();
        const detected: string[] = [];
        if (lower.includes('दूध') || lower.includes('milk') || lower.includes('थान') || lower.includes('swelling')) {
          detected.push('Udder swelling / clotted milk');
        }
        if (lower.includes('बुखार') || lower.includes('ताप') || lower.includes('fever')) {
          detected.push('High fever / warm ears');
        }
        if (lower.includes('खाना') || lower.includes('appetite') || lower.includes('खात नाही')) {
          detected.push('Loss of appetite (खाना छोड़ना)');
        }
        if (lower.includes('दस्त') || lower.includes('जुलाब') || lower.includes('diarrhea')) {
          detected.push('Severe diarrhea');
        }
        if (detected.length > 0) {
          setSelectedSymptoms((prev) => Array.from(new Set([...prev, ...detected])));
        }
      };

      recognition.start();
    } catch (e) {
      console.warn('Speech error', e);
      setIsListening(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImagePreview(ev.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRunAssessment = async () => {
    setLoading(true);
    const combinedSymptoms = [...selectedSymptoms];
    if (voiceText.trim() && !combinedSymptoms.includes(voiceText)) {
      combinedSymptoms.push(`Voice note: "${voiceText}"`);
    }

    try {
      const scan = await analyzeLivestockHealth(
        selectedAnimal,
        combinedSymptoms,
        imagePreview || undefined,
        lang
      );
      setResult(scan);
      onScanComplete(scan);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedSymptoms([]);
    setImagePreview(null);
    setResult(null);
    setVoiceText('');
  };

  return (
    <div id="animal-health-screen" className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Farm Dashboard</span>
        </button>
        <span className="text-xs px-2.5 py-1 bg-amber-100 text-amber-800 rounded-full font-semibold">
          Veterinary Risk Screening
        </span>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>🐄</span> Livestock Health AI Assistant
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Early screening support for cattle, goats, buffalo & poultry. Select symptoms or speak them in Hindi/Marathi.
          </p>
        </div>

        {!result ? (
          <div className="space-y-6">
            {/* Step 1: Animal selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                1. Select Livestock Type
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {LIVESTOCK_TYPES.map((anim) => (
                  <button
                    key={anim.id}
                    type="button"
                    onClick={() => setSelectedAnimal(anim.id)}
                    className={`flex items-center gap-2.5 p-3 rounded-xl border text-xs font-medium text-left transition-colors cursor-pointer ${
                      selectedAnimal === anim.id
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-500'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="text-xl">{anim.icon}</span>
                    <span className="truncate">{anim.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Voice Input & Symptoms */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  2. Select or Speak Observed Symptoms
                </label>
                <button
                  type="button"
                  onClick={handleVoiceInput}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold cursor-pointer transition-colors ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                  }`}
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                  <span>{isListening ? 'Listening...' : 'Speak in Hindi/Marathi'}</span>
                </button>
              </div>

              {voiceText && (
                <div className="mb-3 p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700">
                  <span className="font-semibold text-emerald-700">Heard: </span>
                  "{voiceText}"
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {COMMON_SYMPTOMS.map((sym) => {
                  const active = selectedSymptoms.includes(sym);
                  return (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => toggleSymptom(sym)}
                      className={`px-3 py-1.5 rounded-lg text-xs transition-colors cursor-pointer border ${
                        active
                          ? 'bg-emerald-600 border-emerald-600 text-white font-medium'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {active ? '✓ ' : '+ '}
                      {sym}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Optional Photo Capture */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                3. Photo of Affected Area or Posture (Optional)
              </label>

              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />

              {!imagePreview ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-5 text-center cursor-pointer transition-colors bg-slate-50/50"
                >
                  <Camera className="w-6 h-6 mx-auto text-slate-400 mb-1" />
                  <p className="text-xs font-medium text-slate-700">
                    Tap to capture animal photo or lesion (optional)
                  </p>
                </div>
              ) : (
                <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-900 max-h-48 flex items-center justify-center">
                  <img src={imagePreview} alt="Animal preview" className="max-h-48 object-contain" />
                  <button
                    type="button"
                    onClick={() => setImagePreview(null)}
                    className="absolute top-2 right-2 bg-black/70 hover:bg-black text-white text-xs px-2 py-1 rounded"
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>

            {/* Action button */}
            <button
              id="analyze-animal-btn"
              type="button"
              disabled={loading || (selectedSymptoms.length === 0 && !imagePreview && !voiceText)}
              onClick={handleRunAssessment}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm rounded-xl transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Evaluating Animal Health Risk...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Run Livestock AI Risk Screening</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* Assessment Results */
          <div className="space-y-6">
            {/* Urgent Banner */}
            {result.isUrgent && (
              <div className="p-4 rounded-xl bg-red-50 border-l-4 border-red-600 text-red-900 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold">URGENT VETERINARY CALL RECOMMENDED</h4>
                  <p className="text-xs text-red-700 mt-0.5">
                    Critical indicators detected. Prompt evaluation by a certified veterinary surgeon is essential.
                  </p>
                </div>
              </div>
            )}

            {/* Assessment Header */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Animal</span>
                <h3 className="text-base font-bold text-slate-900 capitalize">{result.targetName}</h3>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Suspected Condition</span>
                <h3 className="text-base font-bold text-emerald-800">{result.diseaseOrCondition}</h3>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Confidence</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full"
                      style={{ width: `${Math.round(result.confidence * 100)}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-800">
                    {Math.round(result.confidence * 100)}%
                  </span>
                </div>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Risk Level</span>
                <div>
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${
                      result.severity === 'critical' || result.severity === 'high'
                        ? 'bg-red-100 text-red-800'
                        : result.severity === 'moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {result.severity}
                  </span>
                </div>
              </div>
            </div>

            {/* Explainable Insights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Observed Physical Indicators
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  {result.indicators.map((ind, i) => (
                    <li key={i}>{ind}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5 mb-2.5">
                  <HeartHandshake className="w-4 h-4 text-emerald-700" />
                  Safe Immediate Nursing Actions
                </h4>
                <ul className="space-y-1.5 text-xs text-emerald-950 list-disc list-inside">
                  {result.immediateActions.map((act, i) => (
                    <li key={i}>{act}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white md:col-span-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  Vaccination & Shed Biosecurity Guidance
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  {result.prevention.map((prev, i) => (
                    <li key={i}>{prev}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Mandatory Veterinary Notice */}
            {/* Veterinary Notice */}
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Veterinary Advisory Notice: </span>
                <span>{result.expertAdvice}</span>
              </div>
            </div>

            {/* Follow-Up Action Box */}
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h5 className="text-xs font-bold text-amber-950">Longitudinal Animal Health Follow-Up</h5>
                <p className="text-[11px] text-amber-800">
                  Re-evaluate symptoms, appetite, and body temperature in 3-5 days.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  alert(`Follow-up scheduled for ${result.targetName} in 3 days! You can monitor recovery in the Follow-Up tab.`);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs transition-colors cursor-pointer flex-shrink-0"
              >
                Schedule Follow-Up Reminder
              </button>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 font-medium text-xs hover:bg-slate-50 cursor-pointer text-center"
              >
                Assess Another Animal
              </button>
              <button
                type="button"
                onClick={onBack}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors cursor-pointer text-center"
              >
                Save & Return to Dashboard
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-[11px] text-center">
        Animal AI is an early screening & triage system, not a replacement for a licensed veterinarian. Never inject prescription antibiotics without veterinary guidance.
      </div>
    </div>
  );
};
