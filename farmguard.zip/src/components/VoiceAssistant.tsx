import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Sparkles, ArrowLeft, Camera, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Language } from '../types';

interface VoiceAssistantProps {
  lang: Language;
  onOpenCropAI: (cropName?: string) => void;
  onOpenAnimalAI: (animalType?: string) => void;
  onBack: () => void;
}

interface VoiceMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  detectedCropOrAnimal?: string;
  actionSuggestion?: string;
  actionType?: 'crop' | 'animal';
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({
  lang,
  onOpenCropAI,
  onOpenAnimalAI,
  onBack
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [hasSpeechSupport, setHasSpeechSupport] = useState(true);
  const [messages, setMessages] = useState<VoiceMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text:
        lang === 'hi'
          ? 'नमस्ते किसान साथी! आप बोलकर अपनी फसल या पशु की समस्या बता सकते हैं। जैसे: "कपास के पत्ते पीले हो रहे हैं" या "गाय ने खाना छोड़ दिया है"।'
          : lang === 'mr'
          ? 'नमस्कार शेतकरी मित्र! आपण बोलून आपल्या पिकाची किंवा जनावरांची अडचण सांगू शकता. उदा. "माझ्या कपाशीची पाने पिवळी पडत आहेत" किंवा "गाय चारा खात नाही आहे".'
          : 'Welcome Farmer! Tap the microphone and speak your crop or livestock concern in English, Hindi, or Marathi. E.g., "My cotton leaves are turning yellow" or "My cow is not eating".'
    }
  ]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setHasSpeechSupport(false);
    }
  }, []);

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  const processFarmerVoice = (userText: string) => {
    const lower = userText.toLowerCase();

    // 1. Identify Crop or Animal
    let detectedTarget = '';
    let isAnimal = false;
    let symptoms: string[] = [];

    // Crop detection keywords
    if (lower.includes('कपास') || lower.includes('कापूस') || lower.includes('cotton')) {
      detectedTarget = 'Cotton (कपास / कापूस)';
    } else if (lower.includes('टमाटर') || lower.includes('टोमॅटो') || lower.includes('tomato')) {
      detectedTarget = 'Tomato (टमाटर)';
    } else if (lower.includes('गेहूं') || lower.includes('गहू') || lower.includes('wheat')) {
      detectedTarget = 'Wheat (गेहूं)';
    } else if (lower.includes('सोयाबीन') || lower.includes('soybean')) {
      detectedTarget = 'Soybean (सोयाबीन)';
    } else if (lower.includes('चावल') || lower.includes('धान') || lower.includes('भात') || lower.includes('rice')) {
      detectedTarget = 'Rice (चावल / धान)';
    } else if (lower.includes('मिर्च') || lower.includes('मिरची') || lower.includes('chili')) {
      detectedTarget = 'Chili (मिर्च)';
    }

    // Livestock detection keywords
    if (lower.includes('गाय') || lower.includes('cow') || lower.includes('cattle')) {
      detectedTarget = 'Cow (गाय)';
      isAnimal = true;
    } else if (lower.includes('भैंस') || lower.includes('म्हैस') || lower.includes('buffalo')) {
      detectedTarget = 'Buffalo (भैंस)';
      isAnimal = true;
    } else if (lower.includes('बकरी') || lower.includes('शेळी') || lower.includes('goat')) {
      detectedTarget = 'Goat (बकरी)';
      isAnimal = true;
    } else if (lower.includes('मुर्गी') || lower.includes('कुक्कुट') || lower.includes('poultry') || lower.includes('chicken')) {
      detectedTarget = 'Poultry (मुर्गी)';
      isAnimal = true;
    }

    // Symptom detection
    if (lower.includes('पीले') || lower.includes('पिवळी') || lower.includes('yellow')) {
      symptoms.push('Yellowing of leaves / Chlorosis');
    }
    if (lower.includes('कीड़ा') || lower.includes('कीड') || lower.includes('pest') || lower.includes('curl') || lower.includes('मुड़')) {
      symptoms.push('Leaf curling or insect vector activity');
    }
    if (lower.includes('खाना') || lower.includes('चारा') || lower.includes('खात नाही') || lower.includes('appetite')) {
      symptoms.push('Loss of appetite / off-feed');
    }
    if (lower.includes('बुखार') || lower.includes('ताप') || lower.includes('fever')) {
      symptoms.push('High body temperature / fever');
    }

    // 2. Synthesize AI reply
    let responseText = '';
    let actionSuggestion = '';
    let actionType: 'crop' | 'animal' | undefined;

    if (detectedTarget) {
      if (!isAnimal) {
        actionType = 'crop';
        if (lang === 'hi') {
          responseText = `मैंने समझा कि आपकी ${detectedTarget} की फसल में समस्या है। पीले पत्ते या पत्तियों का मुड़ना पोषक तत्वों की कमी (नाइट्रोजन/जिंक) या रस चूसक कीटों (Whitefly/Thrips) का संकेत हो सकता है। कृपया प्रभावित पत्ती का एक स्पष्ट फोटो लें ताकि मैं सटीक पहचान कर सकूं।`;
          actionSuggestion = `${detectedTarget} की पत्ती का फोटो स्कैन करें`;
        } else if (lang === 'mr') {
          responseText = `मी समजलो की आपल्या ${detectedTarget} पिकामध्ये अडचण आहे. पाने पिवळी पडणे किंवा चुरमुरणे हे रसशोषक किडी किंवा अन्नद्रव्यांच्या कमतरतेमुळे असू शकते. अचूक निदानासाठी कृपया बाधित पानाचा फोटो काढून स्कॅन करा.`;
          actionSuggestion = `${detectedTarget} च्या पानाचा फोटो स्कॅन करा`;
        } else {
          responseText = `I understand there is an issue with your ${detectedTarget}. Yellowing leaves and curling may indicate sucking pests (whiteflies/thrips) or nutritional deficiency. Please capture a clear leaf photo for accurate AI screening.`;
          actionSuggestion = `Scan photo of ${detectedTarget}`;
        }
      } else {
        actionType = 'animal';
        if (lang === 'hi') {
          responseText = `मैंने नोट किया है कि आपके पशु (${detectedTarget}) में अस्वस्थता के लक्षण हैं। खाना छोड़ना या सुस्ती शुरुआती संक्रमण का संकेत हो सकता है। कृपया ताज़ा चारा और स्वच्छ पानी दें। विस्तृत जांच के लिए पशु की तस्वीर या लक्षण दर्ज करें।`;
          actionSuggestion = `${detectedTarget} की स्वास्थ्य जांच खोलें`;
        } else if (lang === 'mr') {
          responseText = `मी नोंद केली आहे की आपल्या जनावरामध्ये (${detectedTarget}) अस्वस्थतेची लक्षणे दिसत आहेत. चारा न खाणे हा ताप किंवा पचनाच्या त्रासाचा प्राथमिक संकेत असू शकतो. सविस्तर माहितीसाठी जनावराचा फोटो किंवा लक्षणे नोंदवा.`;
          actionSuggestion = `${detectedTarget} ची आरोग्य तपासणी उघडा`;
        } else {
          responseText = `I have noted the symptoms for your ${detectedTarget}. Loss of appetite or lethargy can be an early indicator of fever or digestive issues. Please inspect body temperature and record a detailed screening.`;
          actionSuggestion = `Open ${detectedTarget} Health Screening`;
        }
      }
    } else {
      if (lang === 'hi') {
        responseText = `मुझे आपकी बात समझ आई। क्या आप बता सकते हैं कि यह समस्या किस फसल (जैसे कपास, गेहूं, टमाटर) या पशु (गाय, भैंस, बकरी) में हो रही है?`;
      } else if (lang === 'mr') {
        responseText = `मला आपले बोलणे समजले. कृपया सांगा ही समस्या कोणत्या पिकात (उदा. कापूस, गहू, टोमॅटो) किंवा कोणत्या जनावरात (गाय, म्हैस, शेळी) आहे?`;
      } else {
        responseText = `I heard your observation. Could you please specify which crop (e.g. Cotton, Wheat, Tomato) or animal (Cow, Buffalo, Goat) is affected?`;
      }
    }

    const assistantMsg: VoiceMessage = {
      id: 'bot-' + Date.now(),
      sender: 'assistant',
      text: responseText,
      detectedCropOrAnimal: detectedTarget,
      actionSuggestion,
      actionType
    };

    setMessages((prev) => [...prev, assistantMsg]);
    speakText(responseText);
  };

  const handleStartListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not available in this browser. You can type or use the sample prompts.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = lang === 'hi' ? 'hi-IN' : lang === 'mr' ? 'mr-IN' : 'en-IN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
        setTranscript('');
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onerror = (e: any) => {
        console.warn('Speech error:', e);
        setIsListening(false);
      };

      recognition.onresult = (e: any) => {
        const text = e.results[0][0].transcript;
        setTranscript(text);
        const userMsg: VoiceMessage = {
          id: 'user-' + Date.now(),
          sender: 'user',
          text
        };
        setMessages((prev) => [...prev, userMsg]);
        processFarmerVoice(text);
      };

      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
    }
  };

  const handleSamplePrompt = (sampleText: string) => {
    setTranscript(sampleText);
    const userMsg: VoiceMessage = {
      id: 'user-' + Date.now(),
      sender: 'user',
      text: sampleText
    };
    setMessages((prev) => [...prev, userMsg]);
    processFarmerVoice(sampleText);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Farm Dashboard</span>
        </button>
        <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-semibold">
          Voice-First Farm AI
        </span>
      </div>

      {/* Main card */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col min-h-[560px]">
        
        {/* Assistant Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-800 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-2xl">
              🎙️
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Farmer Voice Assistant</h2>
              <p className="text-xs text-emerald-200">
                Speaks & understands English, हिन्दी, and मराठी
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs px-3 py-1 bg-white/10 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
            <span className="font-semibold">{lang === 'hi' ? 'हिन्दी' : lang === 'mr' ? 'मराठी' : 'English'}</span>
          </div>
        </div>

        {/* Conversation display */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 max-h-[380px] bg-slate-50/50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-tr-none'
                    : 'bg-white border border-slate-200 text-slate-800 shadow-xs rounded-tl-none'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <p>{msg.text}</p>
                  {msg.sender === 'assistant' && (
                    <button
                      type="button"
                      onClick={() => speakText(msg.text)}
                      title="Read aloud"
                      className="text-slate-400 hover:text-emerald-700 flex-shrink-0 cursor-pointer p-1"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {msg.actionSuggestion && (
                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-800">
                      Recommended Next Step:
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (msg.actionType === 'crop') onOpenCropAI();
                        else if (msg.actionType === 'animal') onOpenAnimalAI();
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{msg.actionSuggestion}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Large Microphone Interaction Area */}
        <div className="p-6 bg-white border-t border-slate-200 flex flex-col items-center justify-center space-y-4">
          
          <div className="relative">
            {isListening && (
              <div className="absolute -inset-3 rounded-full bg-emerald-500/20 animate-ping pointer-events-none" />
            )}
            <button
              id="voice-mic-button"
              type="button"
              onClick={handleStartListening}
              className={`w-20 h-20 rounded-full flex items-center justify-center text-white transition-all shadow-md cursor-pointer ${
                isListening
                  ? 'bg-red-500 ring-4 ring-red-200 scale-105'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:scale-95'
              }`}
            >
              {isListening ? (
                <MicOff className="w-9 h-9 animate-pulse" />
              ) : (
                <Mic className="w-9 h-9" />
              )}
            </button>
          </div>

          <p className="text-xs font-medium text-slate-500 text-center">
            {isListening ? (
              <span className="text-emerald-700 font-bold animate-pulse">
                Listening to your voice... Speak clearly into microphone
              </span>
            ) : (
              <span>Tap the large mic button to speak your farm issue</span>
            )}
          </p>

          {/* Quick sample farmer queries in selected languages */}
          <div className="w-full pt-2">
            <p className="text-[11px] font-semibold text-slate-400 uppercase text-center mb-2">
              Or tap a sample question:
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              <button
                type="button"
                onClick={() => handleSamplePrompt('मेरे कपास के पत्ते पीले हो रहे हैं और मुड़ रहे हैं')}
                className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-900 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              >
                "मेरे कपास के पत्ते पीले हो रहे हैं"
              </button>
              <button
                type="button"
                onClick={() => handleSamplePrompt('माझ्या कपाशीची पाने पिवळी पडत आहेत')}
                className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-900 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              >
                "माझ्या कपाशीची पाने पिवळी पडत आहेत"
              </button>
              <button
                type="button"
                onClick={() => handleSamplePrompt('गाय ने आज सुबह से खाना छोड़ दिया है और सुस्त है')}
                className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-900 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              >
                "गाय ने खाना छोड़ दिया है"
              </button>
              <button
                type="button"
                onClick={() => handleSamplePrompt('My tomato leaves have brown concentric rings')}
                className="text-xs px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-50 hover:text-emerald-900 text-slate-700 border border-slate-200 transition-colors cursor-pointer"
              >
                "Tomato leaf brown rings"
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
