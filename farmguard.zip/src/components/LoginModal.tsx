import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Sprout, 
  ShieldCheck, 
  AlertCircle, 
  Mail, 
  Lock, 
  User, 
  Phone, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  ArrowLeft,
  KeyRound,
  Check,
  Building2,
  Sparkles
} from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { 
    signInWithGoogle, 
    signInWithEmail, 
    signUpWithEmail, 
    resetPassword,
    error, 
    clearError, 
    loading 
  } = useAuth();

  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  
  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  
  // Visibility toggles
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Feedback states
  const [formError, setFormError] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const handleGoogleSignIn = async () => {
    clearError();
    setFormError(null);
    await signInWithGoogle();
  };

  const validatePhone = (num: string): boolean => {
    const cleaned = num.replace(/[\s\-\(\)]/g, '');
    return /^\+?[0-9]{10,15}$/.test(cleaned);
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    setFormError(null);

    if (mode === 'signup') {
      if (!name.trim()) {
        setFormError('Please enter your full name.');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setFormError('Please enter a valid email address.');
        return;
      }
      if (!phone.trim()) {
        setFormError('Please enter your mobile phone number.');
        return;
      }
      if (!validatePhone(phone)) {
        setFormError('Please enter a valid mobile number (at least 10 digits).');
        return;
      }
      if (password.length < 6) {
        setFormError('Password must be at least 6 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setFormError('Passwords do not match. Please re-enter both passwords.');
        return;
      }
      try {
        await signUpWithEmail(name, email, password, phone);
      } catch {
        // Error is set in AuthContext
      }
    } else if (mode === 'signin') {
      if (!email.trim()) {
        setFormError('Please enter your registered email address.');
        return;
      }
      if (!password) {
        setFormError('Please enter your password.');
        return;
      }
      try {
        await signInWithEmail(email, password);
      } catch {
        // Error is set in AuthContext
      }
    } else if (mode === 'forgot') {
      if (!email.trim() || !email.includes('@')) {
        setFormError('Please enter a valid email address to receive password reset link.');
        return;
      }
      try {
        await resetPassword(email);
        setResetEmail(email);
        setResetSent(true);
      } catch {
        // Error is set in AuthContext
      }
    }
  };

  const passwordsMatch = confirmPassword.length > 0 && password === confirmPassword;
  const passwordsMismatch = confirmPassword.length > 0 && password !== confirmPassword;

  return (
    <div id="farmguard-auth-container" className="min-h-screen bg-slate-950 flex items-center justify-center p-4 sm:p-6 lg:p-8 font-sans">
      {/* Background ambient lighting effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-emerald-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-[-10%] right-[20%] w-[450px] h-[450px] bg-teal-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        {/* Main Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-black/40 overflow-hidden backdrop-blur-xl">
          
          {/* Header section with brand identity */}
          <div className="p-6 sm:p-8 border-b border-slate-800 text-center relative">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 mb-3 shadow-inner">
              <Sprout className="w-8 h-8" />
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              FarmGuard
            </h1>
            <p className="text-xs sm:text-sm text-emerald-400 font-medium mt-1">
              Early Crop Disease & Livestock Health Intelligence
            </p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Secure enterprise agricultural management platform. Sign in to access real-time AI diagnostics.
            </p>

            {/* Mode Switcher Tabs (Sign In / Register) */}
            {mode !== 'forgot' && (
              <div className="mt-6 p-1 bg-slate-950/80 rounded-xl border border-slate-800 flex">
                <button
                  type="button"
                  id="tab-signin-btn"
                  onClick={() => {
                    setMode('signin');
                    setFormError(null);
                    clearError();
                  }}
                  className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                    mode === 'signin'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  id="tab-signup-btn"
                  onClick={() => {
                    setMode('signup');
                    setFormError(null);
                    clearError();
                  }}
                  className={`flex-1 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-all cursor-pointer ${
                    mode === 'signup'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Create Account
                </button>
              </div>
            )}
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            
            {/* Global Error Banner */}
            {(error || formError) && (
              <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-red-400" />
                <div>
                  <p className="font-semibold text-red-200">Authentication Alert</p>
                  <p className="mt-0.5 leading-relaxed text-red-300">{error || formError}</p>
                </div>
              </div>
            )}

            {/* FORGOT PASSWORD VIEW */}
            {mode === 'forgot' ? (
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('signin');
                      setFormError(null);
                      setResetSent(false);
                      clearError();
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                  <div>
                    <h2 className="text-base font-semibold text-white">Reset Your Password</h2>
                    <p className="text-xs text-slate-400">We will send a password reset verification link to your email.</p>
                  </div>
                </div>

                {resetSent ? (
                  <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-800/50 text-emerald-200 text-xs space-y-3">
                    <div className="flex items-center gap-2 font-semibold text-emerald-300 text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <span>Password Reset Link Dispatched</span>
                    </div>
                    <p className="leading-relaxed text-slate-300">
                      An official password recovery email has been sent to <span className="font-semibold text-white">{resetEmail}</span>.
                    </p>
                    <div className="p-3 bg-slate-950/60 rounded-lg border border-slate-800 text-[11px] text-slate-400 space-y-1">
                      <p>• Click the secure link inside the email to choose a new password.</p>
                      <p>• If it does not appear within 2 minutes, verify your spam or junk folder.</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setMode('signin');
                        setResetSent(false);
                      }}
                      className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-xl transition-colors cursor-pointer text-center"
                    >
                      Return to Sign In
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleEmailSubmit} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Registered Email Address
                      </label>
                      <div className="relative rounded-xl shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                          <Mail className="w-4 h-4" />
                        </div>
                        <input
                          id="forgot-email-input"
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="farmer@example.com"
                          className="block w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      id="send-reset-btn"
                      className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-emerald-950 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                    >
                      {loading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Sending Verification Link...</span>
                        </>
                      ) : (
                        <>
                          <KeyRound className="w-4 h-4" />
                          <span>Send Password Reset Link</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <>
                {/* Official Google OAuth Sign-In Provider */}
                <div>
                  <button
                    id="google-continue-btn"
                    type="button"
                    disabled={loading}
                    onClick={handleGoogleSignIn}
                    className="w-full flex items-center justify-center gap-3 px-4 py-3 border border-slate-700 rounded-xl bg-slate-950 hover:bg-slate-800/80 active:bg-slate-800 text-slate-100 font-medium text-sm transition-all shadow-sm disabled:opacity-50 cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {/* Official Google "G" logo SVG */}
                    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                    <span>{loading ? 'Connecting with Google...' : 'Continue with Google'}</span>
                  </button>
                  <p className="mt-1.5 text-[11px] text-center text-slate-400">
                    Direct account authentication via official Google OAuth
                  </p>
                </div>

                {/* Divider */}
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-800" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-slate-900 px-3 text-slate-500 font-semibold tracking-wider">
                      Or with email and password
                    </span>
                  </div>
                </div>

                {/* Email & Password Form */}
                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  
                  {/* FULL NAME (Registration only) */}
                  {mode === 'signup' && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Full Name <span className="text-emerald-400">*</span>
                      </label>
                      <div className="relative rounded-xl shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                          <User className="w-4 h-4" />
                        </div>
                        <input
                          id="signup-fullname"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="e.g. Ramesh Patil"
                          className="block w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        />
                      </div>
                    </div>
                  )}

                  {/* EMAIL ADDRESS */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Email Address <span className="text-emerald-400">*</span>
                    </label>
                    <div className="relative rounded-xl shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Mail className="w-4 h-4" />
                      </div>
                      <input
                        id="auth-email-input"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="farmer@example.com"
                        className="block w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                      />
                    </div>
                  </div>

                  {/* MOBILE NUMBER (Registration only) */}
                  {mode === 'signup' && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        Mobile Number <span className="text-emerald-400">*</span>
                      </label>
                      <div className="relative rounded-xl shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                          <Phone className="w-4 h-4" />
                        </div>
                        <input
                          id="signup-phone"
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+91 98230 45678"
                          className="block w-full pl-10 pr-3.5 py-2.5 text-sm bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                        />
                      </div>
                      <p className="mt-1 text-[11px] text-slate-400">
                        Used for urgent pest alert SMS and veterinarian emergency dispatch
                      </p>
                    </div>
                  )}

                  {/* PASSWORD */}
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-xs font-semibold text-slate-300">
                        Password <span className="text-emerald-400">*</span>
                      </label>
                      {mode === 'signin' && (
                        <button
                          type="button"
                          id="forgot-password-link"
                          onClick={() => {
                            setMode('forgot');
                            setFormError(null);
                            clearError();
                          }}
                          className="text-xs text-emerald-400 hover:text-emerald-300 font-medium transition-colors cursor-pointer"
                        >
                          Forgot Password?
                        </button>
                      )}
                    </div>
                    <div className="relative rounded-xl shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        id="auth-password-input"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="block w-full pl-10 pr-10 py-2.5 text-sm bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    {mode === 'signup' && (
                      <p className="mt-1 text-[11px] text-slate-400">
                        Must contain at least 6 characters
                      </p>
                    )}
                  </div>

                  {/* CONFIRM PASSWORD (Registration only) */}
                  {mode === 'signup' && (
                    <div>
                      <div className="flex justify-between items-center mb-1.5">
                        <label className="block text-xs font-semibold text-slate-300">
                          Confirm Password <span className="text-emerald-400">*</span>
                        </label>
                        {passwordsMatch && (
                          <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                            <Check className="w-3 h-3" /> Passwords match
                          </span>
                        )}
                        {passwordsMismatch && (
                          <span className="text-[11px] text-red-400 font-semibold">
                            Passwords do not match
                          </span>
                        )}
                      </div>
                      <div className="relative rounded-xl shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                          <Lock className="w-4 h-4" />
                        </div>
                        <input
                          id="signup-confirm-password"
                          type={showConfirmPassword ? 'text' : 'password'}
                          required
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="••••••••"
                          className={`block w-full pl-10 pr-10 py-2.5 text-sm bg-slate-950 border rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:border-emerald-500 outline-none transition-all ${
                            passwordsMismatch 
                              ? 'border-red-500/70 focus:ring-red-500' 
                              : passwordsMatch 
                                ? 'border-emerald-500/70 focus:ring-emerald-500' 
                                : 'border-slate-800 focus:ring-emerald-500'
                          }`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 cursor-pointer"
                        >
                          {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Session Persistence Note */}
                  <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        defaultChecked 
                        disabled
                        className="rounded border-slate-700 bg-slate-950 text-emerald-600 focus:ring-emerald-500 h-3.5 w-3.5"
                      />
                      <span>Stay signed in (Session persistence)</span>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <button
                    id="auth-submit-btn"
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold text-sm rounded-xl transition-all shadow-md shadow-emerald-950 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    {loading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>{mode === 'signin' ? 'Authenticating...' : 'Creating Profile...'}</span>
                      </>
                    ) : (
                      <span>{mode === 'signin' ? 'Sign In to FarmGuard' : 'Create Farmer Account'}</span>
                    )}
                  </button>
                </form>

                {/* Bottom Toggle switch */}
                <div className="pt-2 text-center text-xs text-slate-400">
                  {mode === 'signin' ? (
                    <p>
                      New to FarmGuard?{' '}
                      <button
                        type="button"
                        id="switch-to-register-btn"
                        onClick={() => {
                          setMode('signup');
                          setFormError(null);
                          clearError();
                        }}
                        className="text-emerald-400 font-semibold hover:text-emerald-300 transition-colors cursor-pointer"
                      >
                        Register your farm now
                      </button>
                    </p>
                  ) : (
                    <p>
                      Already have an account?{' '}
                      <button
                        type="button"
                        id="switch-to-signin-btn"
                        onClick={() => {
                          setMode('signin');
                          setFormError(null);
                          clearError();
                        }}
                        className="text-emerald-400 font-semibold hover:text-emerald-300 transition-colors cursor-pointer"
                      >
                        Sign in to existing account
                      </button>
                    </p>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Footer Security Badges */}
          <div className="p-4 bg-slate-950/60 border-t border-slate-800 text-[11px] text-slate-500 flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Firebase Auth & Session Encrypted</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Private Farmer Data Isolation</span>
            </div>
          </div>
        </div>

        {/* Outer subtext */}
        <p className="mt-4 text-center text-xs text-slate-500">
          Protected by Google Firebase Authentication • All rights reserved
        </p>
      </div>
    </div>
  );
};
