import React, { useState } from 'react';
import { HealthScan } from '../types';
import { 
  ArrowLeft, 
  Calendar, 
  CheckCircle2, 
  Info, 
  ShieldAlert, 
  ChevronRight,
  Filter,
  Camera,
  X,
  Sparkles,
  FileDown
} from 'lucide-react';
import { ExportReportModal } from './ExportReportModal';

interface ScanHistoryProps {
  scans: HealthScan[];
  onBack: () => void;
  onSelectScan: (scan: HealthScan) => void;
  onOpenCropAI?: () => void;
  onOpenAnimalAI?: () => void;
}

export const ScanHistory: React.FC<ScanHistoryProps> = ({ 
  scans, 
  onBack, 
  onSelectScan,
  onOpenCropAI,
  onOpenAnimalAI
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'crop' | 'livestock' | 'high_risk' | 'follow_up'>('all');
  const [selectedModalScan, setSelectedModalScan] = useState<HealthScan | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const filteredScans = scans.filter((scan) => {
    if (activeFilter === 'crop') return scan.type === 'crop';
    if (activeFilter === 'livestock') return scan.type === 'livestock';
    if (activeFilter === 'high_risk') return scan.severity === 'critical' || scan.severity === 'high';
    if (activeFilter === 'follow_up') return scan.severity === 'moderate' || scan.severity === 'high';
    return true;
  });

  return (
    <div id="scan-history-screen" className="max-w-4xl mx-auto space-y-6 pb-14">
      {/* Top Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsExportModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs cursor-pointer transition-colors"
          >
            <FileDown className="w-4 h-4" />
            <span>Export Summary PDF</span>
          </button>

          <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-bold">
            {scans.length} Saved Records
          </span>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-slate-900 mb-1 flex items-center gap-2">
              <span>📊</span> Farm Health Scan Timeline & History
            </h2>
            <p className="text-xs text-slate-500">
              Timeline tracking continuous early detection assessments across crops and livestock.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsExportModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold cursor-pointer transition-colors self-start sm:self-auto border border-slate-200"
          >
            <FileDown className="w-4 h-4 text-emerald-700" />
            <span>PDF Consultant Audit</span>
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap gap-2 border-b border-slate-100 pb-3">
          {[
            { id: 'all', label: 'All Records' },
            { id: 'crop', label: 'Crops Only' },
            { id: 'livestock', label: 'Livestock Only' },
            { id: 'high_risk', label: 'High Risk' },
            { id: 'follow_up', label: 'Needs Follow-Up' }
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                activeFilter === tab.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* List */}
        {filteredScans.length === 0 ? (
          <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-3">
            <p className="text-sm font-semibold text-slate-700">No matching scan records</p>
            <p className="text-xs text-slate-400">
              Start by taking a photo in Crop Health or running an Animal Health assessment.
            </p>
            <div className="flex justify-center gap-3 pt-2">
              {onOpenCropAI && (
                <button
                  type="button"
                  onClick={onOpenCropAI}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                >
                  Scan Crop Leaf
                </button>
              )}
              {onOpenAnimalAI && (
                <button
                  type="button"
                  onClick={onOpenAnimalAI}
                  className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold"
                >
                  Screen Livestock
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredScans.map((scan) => (
              <div
                key={scan.id}
                onClick={() => setSelectedModalScan(scan)}
                className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-500 bg-white hover:bg-slate-50/50 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  {scan.imageUrl ? (
                    <img
                      src={scan.imageUrl}
                      alt={scan.targetName}
                      className="w-16 h-16 rounded-xl object-cover border border-slate-200 flex-shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-slate-100 flex items-center justify-center text-3xl flex-shrink-0">
                      {scan.type === 'crop' ? '🌱' : '🐄'}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 uppercase">
                        {scan.targetName}
                      </span>
                      <span className="text-xs text-slate-400">•</span>
                      <span className="text-xs font-semibold text-emerald-800">
                        {scan.diseaseOrCondition}
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                      {scan.immediateActions[0] || 'Standard agricultural advisory'}
                    </p>

                    <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(scan.date).toLocaleDateString()}
                      </span>
                      <span>•</span>
                      <span>{Math.round(scan.confidence * 100)}% Confidence</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-center">
                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                      scan.severity === 'critical' || scan.severity === 'high'
                        ? 'bg-red-100 text-red-800'
                        : scan.severity === 'moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {scan.severity}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Detailed Scan View Modal */}
      {selectedModalScan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg">{selectedModalScan.type === 'crop' ? '🌱' : '🐄'}</span>
                <div>
                  <h3 className="text-base font-bold text-slate-900 uppercase">
                    {selectedModalScan.targetName} Report
                  </h3>
                  <p className="text-xs text-slate-400">{new Date(selectedModalScan.date).toLocaleString()}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedModalScan(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {selectedModalScan.imageUrl && (
              <div className="rounded-2xl overflow-hidden border border-slate-200 max-h-56">
                <img
                  src={selectedModalScan.imageUrl}
                  alt={selectedModalScan.targetName}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1 text-xs">
              <span className="text-emerald-900 font-bold uppercase tracking-wider text-[10px]">
                Identified Condition
              </span>
              <p className="text-sm font-black text-emerald-950">
                {selectedModalScan.diseaseOrCondition}
              </p>
              <div className="flex gap-4 pt-1 text-emerald-800 text-xs">
                <span>Severity: <strong className="uppercase">{selectedModalScan.severity}</strong></span>
                <span>Confidence: <strong>{Math.round(selectedModalScan.confidence * 100)}%</strong></span>
              </div>
            </div>

            {selectedModalScan.symptoms && selectedModalScan.symptoms.length > 0 && (
              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-slate-800">Observed Symptoms:</h4>
                <ul className="list-disc list-inside text-slate-600 space-y-0.5">
                  {selectedModalScan.symptoms.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedModalScan.immediateActions && selectedModalScan.immediateActions.length > 0 && (
              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-slate-800">Immediate Action Plan:</h4>
                <ul className="list-disc list-inside text-slate-600 space-y-0.5">
                  {selectedModalScan.immediateActions.map((a, idx) => (
                    <li key={idx}>{a}</li>
                  ))}
                </ul>
              </div>
            )}

            {selectedModalScan.prevention && selectedModalScan.prevention.length > 0 && (
              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-slate-800">Preventive Measures:</h4>
                <ul className="list-disc list-inside text-slate-600 space-y-0.5">
                  {selectedModalScan.prevention.map((p, idx) => (
                    <li key={idx}>{p}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="pt-2 flex justify-between items-center">
              <button
                type="button"
                onClick={() => {
                  setSelectedModalScan(null);
                  setIsExportModalOpen(true);
                }}
                className="px-3 py-2 rounded-xl border border-emerald-300 text-emerald-800 bg-emerald-50 text-xs font-bold hover:bg-emerald-100 cursor-pointer flex items-center gap-1.5"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>Export Audit PDF</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModalScan(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-black cursor-pointer"
              >
                Close Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export PDF Report Modal */}
      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        scans={scans}
      />
    </div>
  );
};
