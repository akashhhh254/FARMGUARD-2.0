import React from 'react';

interface FooterProps {
  onOpenLegal: (type: 'privacy' | 'terms' | 'support') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  return (
    <footer id="farmguard-footer" className="bg-white border-t border-slate-200 mt-auto py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-600">
        <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-3 text-center sm:text-left">
          <span className="font-black tracking-wider text-emerald-950 text-sm">FARM GUARD</span>
          <span className="hidden sm:inline text-slate-300">•</span>
          <span className="text-slate-600">AI-based early detection for crop disease and livestock health</span>
        </div>

        <div className="flex items-center gap-4 text-xs font-medium">
          <button
            type="button"
            onClick={() => onOpenLegal('privacy')}
            className="hover:text-emerald-700 transition-colors cursor-pointer"
          >
            Privacy Policy
          </button>
          <span className="text-slate-300">|</span>
          <button
            type="button"
            onClick={() => onOpenLegal('terms')}
            className="hover:text-emerald-700 transition-colors cursor-pointer"
          >
            Terms of Use
          </button>
          <span className="text-slate-300">|</span>
          <button
            type="button"
            onClick={() => onOpenLegal('support')}
            className="hover:text-emerald-700 transition-colors cursor-pointer"
          >
            Contact / Support
          </button>
        </div>

        <div className="text-slate-400 text-[11px] text-center md:text-right">
          © FARM GUARD — All Rights Reserved.
        </div>
      </div>
    </footer>
  );
};
