import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserProfile, Language } from '../types';
import { 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Tractor, 
  Languages, 
  Save, 
  CheckCircle2, 
  ArrowLeft,
  Camera,
  Settings,
  Shield,
  FileText,
  PhoneCall,
  LogOut,
  Bell
} from 'lucide-react';

interface FarmerProfileProps {
  onBack: () => void;
  onOpenLocationModal: () => void;
  onOpenSettings: (initialTab?: 'settings' | 'support' | 'privacy' | 'terms') => void;
}

export const FarmerProfile: React.FC<FarmerProfileProps> = ({ 
  onBack, 
  onOpenLocationModal,
  onOpenSettings
}) => {
  const { userProfile, updateFarmerProfile, user, signOut } = useAuth();

  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [phoneNumber, setPhoneNumber] = useState(userProfile?.phoneNumber || '');
  const [village, setVillage] = useState(userProfile?.village || '');
  const [district, setDistrict] = useState(userProfile?.district || '');
  const [state, setState] = useState(userProfile?.state || 'Maharashtra');
  const [farmName, setFarmName] = useState(userProfile?.farmName || '');
  const [farmSize, setFarmSize] = useState(userProfile?.farmSize || '5 Acres');
  const [crops, setCrops] = useState((userProfile?.crops || ['Cotton', 'Wheat']).join(', '));
  const [livestock, setLivestock] = useState((userProfile?.livestock || ['Cow', 'Buffalo']).join(', '));
  const [preferredLang, setPreferredLang] = useState<Language>(userProfile?.preferredLanguage || 'en');
  const [saved, setSaved] = useState(false);
  const [photoURL, setPhotoURL] = useState(userProfile?.photoURL || user?.photoURL || '');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateFarmerProfile({
      displayName,
      phoneNumber,
      village,
      district,
      state,
      farmName,
      farmSize,
      crops: crops.split(',').map((c) => c.trim()).filter(Boolean),
      livestock: livestock.split(',').map((l) => l.trim()).filter(Boolean),
      preferredLanguage: preferredLang,
      photoURL: photoURL || undefined
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setPhotoURL(ev.target?.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  return (
    <div id="farmer-profile-screen" className="max-w-4xl mx-auto space-y-6 pb-14">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Farm Dashboard</span>
        </button>
        <span className="text-xs px-2.5 py-1 bg-slate-100 text-slate-700 rounded-full font-medium">
          Farmer UID: {userProfile?.uid ? userProfile.uid.slice(0, 10) + '...' : 'Guest'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Left Column: Profile Card & Menu */}
        <div className="space-y-5">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 text-center space-y-3 shadow-xs">
            <div className="relative w-20 h-20 mx-auto">
              <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-2xl overflow-hidden border-2 border-emerald-500">
                {photoURL ? (
                  <img src={photoURL} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  displayName.charAt(0) || 'F'
                )}
              </div>
              <label
                htmlFor="profile-pic-upload"
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow"
              >
                <Camera className="w-3.5 h-3.5" />
              </label>
              <input
                id="profile-pic-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-900">{displayName || 'Farmer'}</h3>
              <p className="text-xs text-slate-500 truncate">{userProfile?.email || 'Authenticated User'}</p>
            </div>

            <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 space-y-1 text-left">
              <div className="flex justify-between">
                <span>Farm:</span>
                <strong className="text-slate-800">{farmName || 'My Farm'}</strong>
              </div>
              <div className="flex justify-between">
                <span>Location:</span>
                <span className="text-slate-800">{district ? `${district}, ${state}` : 'Not set'}</span>
              </div>
            </div>
          </div>

          {/* Quick Profile Navigation (Section 31 requirement) */}
          <div className="bg-white rounded-3xl border border-slate-200 p-4 shadow-xs space-y-1 text-xs font-semibold">
            <button
              type="button"
              onClick={onOpenLocationModal}
              className="w-full p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>Location Settings</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenSettings('settings')}
              className="w-full p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <Settings className="w-4 h-4 text-slate-500" />
              <span>App Settings & Preferences</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenSettings('support')}
              className="w-full p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <PhoneCall className="w-4 h-4 text-blue-600" />
              <span>Help & Support Helplines</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenSettings('privacy')}
              className="w-full p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <Shield className="w-4 h-4 text-slate-500" />
              <span>Privacy Policy</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenSettings('terms')}
              className="w-full p-2.5 rounded-xl hover:bg-slate-50 text-slate-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <FileText className="w-4 h-4 text-slate-500" />
              <span>Terms of Use</span>
            </button>
            <div className="border-t border-slate-100 my-1"></div>
            <button
              type="button"
              onClick={signOut}
              className="w-full p-2.5 rounded-xl hover:bg-red-50 text-red-700 flex items-center gap-2.5 cursor-pointer text-left"
            >
              <LogOut className="w-4 h-4 text-red-600" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Right Column: Editable Profile Details */}
        <div className="md:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <User className="w-5 h-5 text-emerald-600" />
              Farmer & Land Holding Details
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Personalize localized crop disease alerts, regional advisory, and livestock care.
            </p>
          </div>

          {saved && (
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Profile successfully updated and synchronized!</span>
            </div>
          )}

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+91 98000 00000"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Village / Town</label>
                <input
                  type="text"
                  value={village}
                  onChange={(e) => setVillage(e.target.value)}
                  placeholder="Village Name"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">District & State</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="District"
                    className="w-1/2 text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="State"
                    className="w-1/2 text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Farm Name</label>
                <input
                  type="text"
                  value={farmName}
                  onChange={(e) => setFarmName(e.target.value)}
                  placeholder="Green Acres Farm"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Farm Size</label>
                <input
                  type="text"
                  value={farmSize}
                  onChange={(e) => setFarmSize(e.target.value)}
                  placeholder="e.g. 5 Acres"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Cultivated Crops (Comma separated)
                </label>
                <input
                  type="text"
                  value={crops}
                  onChange={(e) => setCrops(e.target.value)}
                  placeholder="Cotton, Soybean, Wheat, Chili, Tomato"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Owned Livestock (Comma separated)
                </label>
                <input
                  type="text"
                  value={livestock}
                  onChange={(e) => setLivestock(e.target.value)}
                  placeholder="Cow, Buffalo, Goat, Poultry"
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">Preferred Language</label>
                <select
                  value={preferredLang}
                  onChange={(e) => setPreferredLang(e.target.value as Language)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                >
                  <option value="en">English (English)</option>
                  <option value="hi">हिन्दी (Hindi)</option>
                  <option value="mr">मराठी (Marathi)</option>
                </select>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                id="save-profile-btn"
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save & Update Profile</span>
              </button>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
};
