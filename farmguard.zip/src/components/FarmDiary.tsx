import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  Plus, 
  Calendar, 
  ArrowLeft, 
  Image as ImageIcon, 
  X, 
  Tag, 
  Camera, 
  Filter 
} from 'lucide-react';
import { FarmDiaryEntry, Language } from '../types';
import { fetchUserDiary, saveUserDiaryEntry } from '../utils/storage';

interface FarmDiaryProps {
  userId: string;
  lang: Language;
  onBack: () => void;
}

export const FarmDiary: React.FC<FarmDiaryProps> = ({ userId, lang, onBack }) => {
  const [entries, setEntries] = useState<FarmDiaryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<FarmDiaryEntry['category']>('crop');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    async function loadDiary() {
      try {
        const loaded = await fetchUserDiary(userId);
        setEntries(loaded);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadDiary();
  }, [userId]);

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageUrl(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const newEntry = await saveUserDiaryEntry(userId, {
      title: title.trim(),
      category,
      date,
      description: description.trim(),
      imageUrl: imageUrl || undefined
    });

    setEntries((prev) => [newEntry, ...prev]);
    setShowAddModal(false);
    setTitle('');
    setDescription('');
    setImageUrl('');
  };

  const filteredEntries = filterCategory === 'all'
    ? entries
    : entries.filter((e) => e.category === filterCategory);

  const getCategoryBadge = (cat: FarmDiaryEntry['category']) => {
    const map: Record<string, { label: string; color: string }> = {
      crop: { label: 'Crop Activity', color: 'bg-emerald-100 text-emerald-800' },
      livestock: { label: 'Livestock Event', color: 'bg-blue-100 text-blue-800' },
      disease: { label: 'Disease Incident', color: 'bg-red-100 text-red-800' },
      irrigation: { label: 'Irrigation', color: 'bg-cyan-100 text-cyan-800' },
      fertilizer: { label: 'Fertilizer Applied', color: 'bg-amber-100 text-amber-800' },
      weather: { label: 'Weather Event', color: 'bg-purple-100 text-purple-800' },
      harvest: { label: 'Harvest Log', color: 'bg-yellow-100 text-yellow-800' },
      expense: { label: 'Expense/Financial', color: 'bg-slate-100 text-slate-800' },
      note: { label: 'Field Note', color: 'bg-gray-100 text-gray-800' }
    };
    return map[cat] || { label: cat, color: 'bg-slate-100 text-slate-800' };
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-14">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Diary Entry</span>
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>📖</span> Digital Farm Diary
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Keep a permanent digital record of field observations, spray dates, veterinary events, and harvests.
          </p>
        </div>

        {/* Categories filter bar */}
        <div className="flex flex-wrap gap-2 border-b border-slate-100 pb-3">
          {[
            { id: 'all', label: 'All Logs' },
            { id: 'crop', label: 'Crops' },
            { id: 'livestock', label: 'Livestock' },
            { id: 'disease', label: 'Disease Sightings' },
            { id: 'irrigation', label: 'Irrigation' },
            { id: 'fertilizer', label: 'Fertilizer' },
            { id: 'harvest', label: 'Harvest' }
          ].map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setFilterCategory(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition-colors ${
                filterCategory === c.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Entries list */}
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">Loading diary records...</div>
        ) : filteredEntries.length === 0 ? (
          <div className="py-12 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold text-slate-700">No diary entries found</p>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Start recording your farm activities, pest sightings, and field work.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredEntries.map((entry) => {
              const badge = getCategoryBadge(entry.category);
              return (
                <div
                  key={entry.id}
                  className="p-5 rounded-2xl border border-slate-200 hover:border-slate-300 bg-white transition-all space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase ${badge.color}`}>
                        {badge.label}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">{entry.title}</h4>
                    </div>
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {entry.date}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{entry.description}</p>

                  {entry.imageUrl && (
                    <div className="rounded-xl overflow-hidden max-h-48 w-full sm:w-72 border border-slate-200 bg-slate-100">
                      <img
                        src={entry.imageUrl}
                        alt="Diary visual record"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* New Entry Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">Record New Farm Entry</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEntry} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Activity Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sowing hybrid cotton in Field B"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="crop">Crop Activity</option>
                    <option value="livestock">Livestock Event</option>
                    <option value="disease">Disease Incident</option>
                    <option value="irrigation">Irrigation</option>
                    <option value="fertilizer">Fertilizer Application</option>
                    <option value="weather">Weather Event</option>
                    <option value="harvest">Harvest Event</option>
                    <option value="note">General Note</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description / Field Details *
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe quantity applied, seed variety, observed symptoms, or field condition..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Attach Photo (Optional)
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageFile}
                  className="hidden"
                />
                {!imageUrl ? (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-3 px-3 rounded-xl border border-dashed border-slate-300 hover:bg-slate-50 text-slate-600 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Camera className="w-4 h-4 text-emerald-600" />
                    <span>Upload field or leaf photo</span>
                  </button>
                ) : (
                  <div className="relative rounded-xl overflow-hidden border border-slate-200">
                    <img src={imageUrl} alt="Attached preview" className="max-h-40 w-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="absolute top-2 right-2 bg-black/70 hover:bg-black text-white p-1 rounded-full text-xs"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
