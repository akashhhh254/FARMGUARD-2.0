import React, { useState, useRef } from 'react';
import { analyzeCropHealth } from '../services/aiService';
import { HealthScan, Language } from '../types';
import { 
  Camera, 
  Upload, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ArrowLeft, 
  RefreshCw, 
  ShieldAlert,
  HelpCircle,
  FileCheck2
} from 'lucide-react';

interface CropDetectionProps {
  lang: Language;
  onScanComplete: (scan: HealthScan) => void;
  onBack: () => void;
}

const SUPPORTED_CROPS = [
  { id: 'cotton', label: 'Cotton (कपास / कापूस)', icon: '🌱' },
  { id: 'tomato', label: 'Tomato (टमाटर / टोमॅटो)', icon: '🍅' },
  { id: 'wheat', label: 'Wheat (गेहूं / गहू)', icon: '🌾' },
  { id: 'rice', label: 'Rice / Paddy (चावल / भात)', icon: '🍚' },
  { id: 'soybean', label: 'Soybean (सोयाबीन)', icon: '🌿' },
  { id: 'chili', label: 'Chili (मिर्च / मिरची)', icon: '🌶️' },
  { id: 'potato', label: 'Potato (आलू / बटाटा)', icon: '🥔' },
  { id: 'maize', label: 'Maize / Corn (मक्का / मका)', icon: '🌽' },
  { id: 'sugarcane', label: 'Sugarcane (गन्ना / ऊस)', icon: '🎋' },
  { id: 'onion', label: 'Onion (प्याज / कांदा)', icon: '🧅' },
  { id: 'pulses', label: 'Pulses / Tur (दाल / तूर)', icon: '🫘' },
  { id: 'other', label: 'Other Crops (अन्य फसल)', icon: '🪴' }
];

export const CropDetection: React.FC<CropDetectionProps> = ({ lang, onScanComplete, onBack }) => {
  const [selectedCrop, setSelectedCrop] = useState('cotton');
  const [customCrop, setCustomCrop] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [qualityWarning, setQualityWarning] = useState<string | null>(null);
  const [result, setResult] = useState<HealthScan | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageFile = (file: File) => {
    // Quality check
    if (file.size < 10000) {
      setQualityWarning('Image file is too small or blurry. Please upload a clear photo of the infected leaf.');
      return;
    }
    setQualityWarning(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageFile(e.target.files[0]);
    }
  };

  const handleRunAnalysis = async () => {
    const cropName = selectedCrop === 'other' ? (customCrop || 'Crop') : selectedCrop;
    setLoading(true);
    setQualityWarning(null);

    try {
      const scan = await analyzeCropHealth(cropName, imagePreview || undefined, lang);
      setResult(scan);
      onScanComplete(scan);
    } catch (err) {
      console.error(err);
      setQualityWarning('Analysis timed out. Please try again with a clearer leaf photo.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setImagePreview(null);
    setResult(null);
    setQualityWarning(null);
  };

  // Sample leaf images for quick demo without camera upload
  const loadSampleImage = (type: string) => {
    if (type === 'cotton') {
      setSelectedCrop('cotton');
      setImagePreview('https://images.unsplash.com/photo-1599818816942-0f04dbd22aa4?w=600&auto=format&fit=crop&q=80');
    } else if (type === 'tomato') {
      setSelectedCrop('tomato');
      setImagePreview('https://images.unsplash.com/photo-1592417817098-8f3d6910985c?w=600&auto=format&fit=crop&q=80');
    } else {
      setSelectedCrop('wheat');
      setImagePreview('https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&auto=format&fit=crop&q=80');
    }
  };

  return (
    <div id="crop-detection-screen" className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Farm Dashboard</span>
        </button>
        <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full font-semibold">
          Primary AI Module
        </span>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>🌱</span> Crop Disease Early Detection AI
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Capture or upload a clear leaf image to diagnose leaf spot, blights, pests, and fungal stress.
          </p>
        </div>

        {!result ? (
          <div className="space-y-6">
            {/* Step 1: Select Crop */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                1. Select Your Crop
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {SUPPORTED_CROPS.map((crop) => (
                  <button
                    key={crop.id}
                    type="button"
                    onClick={() => setSelectedCrop(crop.id)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-medium text-left transition-colors cursor-pointer ${
                      selectedCrop === crop.id
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-semibold ring-1 ring-emerald-500'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <span className="text-base">{crop.icon}</span>
                    <span className="truncate">{crop.label}</span>
                  </button>
                ))}
              </div>

              {selectedCrop === 'other' && (
                <div className="mt-3">
                  <input
                    type="text"
                    placeholder="Enter crop name (e.g. Groundnut, Mustard, Papaya)"
                    value={customCrop}
                    onChange={(e) => setCustomCrop(e.target.value)}
                    className="w-full text-sm px-3.5 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              )}
            </div>

            {/* Step 2: Upload Leaf Photo */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  2. Leaf Image Capture
                </label>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span>Quick Demo Samples:</span>
                  <button
                    type="button"
                    onClick={() => loadSampleImage('cotton')}
                    className="text-emerald-700 font-semibold underline hover:text-emerald-800 cursor-pointer"
                  >
                    Cotton Leaf
                  </button>
                  <span>•</span>
                  <button
                    type="button"
                    onClick={() => loadSampleImage('tomato')}
                    className="text-emerald-700 font-semibold underline hover:text-emerald-800 cursor-pointer"
                  >
                    Tomato
                  </button>
                  <span>•</span>
                  <button
                    type="button"
                    onClick={() => loadSampleImage('wheat')}
                    className="text-emerald-700 font-semibold underline hover:text-emerald-800 cursor-pointer"
                  >
                    Wheat
                  </button>
                </div>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleFileChange}
              />

              {!imagePreview ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-2xl p-8 text-center cursor-pointer transition-colors bg-slate-50/50 hover:bg-emerald-50/20"
                >
                  <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-3">
                    <Camera className="w-7 h-7" />
                  </div>
                  <p className="text-sm font-semibold text-slate-800">
                    Tap to open camera or browse leaf photo
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Supports JPG, PNG from phone gallery or direct photo
                  </p>
                </div>
              ) : (
                <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 max-h-80 flex items-center justify-center">
                  <img
                    src={imagePreview}
                    alt="Leaf preview"
                    className="max-h-80 w-auto object-contain"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-3 right-3 bg-black/70 hover:bg-black text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer backdrop-blur-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Change Image
                  </button>
                </div>
              )}

              {qualityWarning && (
                <div className="mt-3 p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{qualityWarning}</span>
                </div>
              )}
            </div>

            {/* Action button */}
            <button
              id="analyze-crop-btn"
              type="button"
              disabled={loading || !imagePreview}
              onClick={handleRunAnalysis}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold text-sm rounded-xl transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Analyzing with Multimodal AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Analyze Leaf Health Now</span>
                </>
              )}
            </button>
          </div>
        ) : (
          /* Step 3: Explainable AI Result Card */
          <div className="space-y-6">
            {/* Urgent Alert Banner if critical */}
            {result.isUrgent && (
              <div className="p-4 rounded-xl bg-red-50 border-l-4 border-red-600 text-red-900 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold">URGENT AGRICULTURAL ATTENTION RECOMMENDED</h4>
                  <p className="text-xs text-red-700 mt-0.5">
                    High-severity risk identified. Rapid intervention is recommended to avoid yield reduction.
                  </p>
                </div>
              </div>
            )}

            {/* Overview pill header */}
            <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Crop</span>
                <h3 className="text-base font-bold text-slate-900 capitalize">{result.targetName}</h3>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Identified Condition</span>
                <h3 className="text-base font-bold text-emerald-800">{result.diseaseOrCondition}</h3>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Confidence</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full"
                      style={{ width: `${Math.round(result.confidence * 100)}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-slate-800">
                    {Math.round(result.confidence * 100)}%
                  </span>
                </div>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase">Severity</span>
                <div>
                  <span
                    className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${
                      result.severity === 'critical' || result.severity === 'high'
                        ? 'bg-red-100 text-red-800'
                        : result.severity === 'moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {result.severity}
                  </span>
                </div>
              </div>
            </div>

            {/* AI Explainability Sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Visible Indicators */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Visible Indicators (Why AI Detected This)
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  {result.indicators.map((ind, i) => (
                    <li key={i}>{ind}</li>
                  ))}
                </ul>
              </div>

              {/* Pathogen / Causes */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
                  <Info className="w-4 h-4 text-blue-600" />
                  Pathogen & Favorable Conditions
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  {(result.causes || ['Environmental humidity', 'Spore contact']).map((cause, i) => (
                    <li key={i}>{cause}</li>
                  ))}
                </ul>
              </div>

              {/* Immediate Action Plan */}
              <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5 mb-2.5">
                  <FileCheck2 className="w-4 h-4 text-emerald-700" />
                  Immediate Safe Action Plan
                </h4>
                <ul className="space-y-1.5 text-xs text-emerald-950 list-disc list-inside">
                  {result.immediateActions.map((act, i) => (
                    <li key={i}>{act}</li>
                  ))}
                </ul>
              </div>

              {/* Prevention for Next Season */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 mb-2.5">
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  Long-term Prevention & Hygiene
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  {result.prevention.map((prev, i) => (
                    <li key={i}>{prev}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Expert Advice Note */}
            <div className="p-3.5 rounded-xl bg-slate-100 text-slate-700 text-xs flex items-start gap-2.5">
              <HelpCircle className="w-4 h-4 text-slate-500 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Agronomist Consultation Guidance: </span>
                <span>{result.expertAdvice}</span>
              </div>
            </div>

            {/* Follow-Up Action Box */}
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h5 className="text-xs font-bold text-emerald-950">Longitudinal AI Follow-Up</h5>
                <p className="text-[11px] text-emerald-800">
                  Track recovery over the next 5-7 days after applying treatment.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  alert(`Follow-up scheduled for ${result.targetName} in 5 days! You can track this in the Follow-Up tab.`);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs transition-colors cursor-pointer flex-shrink-0"
              >
                Schedule Follow-Up Reminder
              </button>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 font-medium text-xs hover:bg-slate-50 cursor-pointer text-center"
              >
                Scan Another Crop Leaf
              </button>
              <button
                type="button"
                onClick={onBack}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors cursor-pointer text-center"
              >
                Save & Return to Dashboard
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Decision Support Disclaimer */}
      <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-500 text-[11px] text-center">
        FarmGuard AI provides early decision support and screening. It is not a replacement for certified agronomists or licensed chemical advisory. Follow local package labels before spraying.
      </div>
    </div>
  );
};
