import React, { useState } from 'react';
import { 
  CloudSun, 
  Droplets, 
  Wind, 
  Thermometer, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  ShieldCheck, 
  Info, 
  ArrowLeft, 
  Sparkles,
  RefreshCw,
  Sprout
} from 'lucide-react';
import { Language, WeatherData } from '../types';

interface WeatherAdvisoryProps {
  lang: Language;
  locationName: string;
  onOpenLocationModal: () => void;
  onBack: () => void;
}

export const WeatherAdvisory: React.FC<WeatherAdvisoryProps> = ({
  lang,
  locationName,
  onOpenLocationModal,
  onBack
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'weather' | 'irrigation' | 'fertilizer'>('weather');
  const [selectedCrop, setSelectedCrop] = useState('cotton');
  const [selectedGrowthStage, setSelectedGrowthStage] = useState('flowering');
  const [soilType, setSoilType] = useState('black_cotton');

  // Realistic regional agro-meteorological data
  const weather: WeatherData = {
    temp: 29,
    condition: 'Partly Cloudy & Humid',
    humidity: 76,
    rainfallRisk: '35% chance of light showers in next 36h',
    windSpeed: 14,
    advisory:
      'High relative humidity (>75%) coupled with cloudy sky creates favorable conditions for fungal leaf spots (Alternaria, Cercospora). Delay nitrogenous top-dressing and ensure field drainage channels are cleared.',
    locationName: locationName || 'Central Agricultural Zone',
    isLive: true,
    forecast: [
      { day: 'Today', temp: 29, condition: 'Partly Cloudy', rainProb: 35 },
      { day: 'Tomorrow', temp: 28, condition: 'Scattered Showers', rainProb: 65 },
      { day: 'Thursday', temp: 31, condition: 'Clear Sky', rainProb: 15 },
      { day: 'Friday', temp: 32, condition: 'Sunny & Dry', rainProb: 10 },
      { day: 'Saturday', temp: 30, condition: 'Humid Breeze', rainProb: 20 }
    ]
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-14">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Zone:</span>
          <button
            type="button"
            onClick={onOpenLocationModal}
            className="text-xs px-3 py-1 rounded-xl bg-emerald-50 text-emerald-800 font-bold border border-emerald-200 hover:bg-emerald-100 transition-colors cursor-pointer"
          >
            {weather.locationName} (Change)
          </button>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 max-w-md">
        <button
          type="button"
          onClick={() => setActiveSubTab('weather')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'weather'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Weather & Advisory
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('irrigation')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'irrigation'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Smart Irrigation
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('fertilizer')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeSubTab === 'fertilizer'
              ? 'bg-white text-emerald-950 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Fertilizer & Care
        </button>
      </div>

      {/* 1. WEATHER & ADVISORY SECTION */}
      {activeSubTab === 'weather' && (
        <div className="space-y-6">
          {/* Main Weather Hero Card */}
          <div className="bg-gradient-to-br from-emerald-800 via-emerald-900 to-slate-900 text-white p-7 rounded-3xl shadow-sm relative overflow-hidden">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-xs font-semibold text-emerald-200">
                  <CloudSun className="w-4 h-4" />
                  <span>Live Agricultural Weather Station</span>
                </div>
                <h2 className="text-4xl sm:text-5xl font-black tracking-tight">{weather.temp}°C</h2>
                <p className="text-lg font-medium text-emerald-100">{weather.condition}</p>
                <p className="text-xs text-emerald-300">
                  Rain Outlook: <strong className="text-white">{weather.rainfallRisk}</strong>
                </p>
              </div>

              {/* Weather Stats Grid */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10">
                  <span className="text-[11px] text-emerald-200 uppercase font-bold tracking-wider flex items-center gap-1.5">
                    <Droplets className="w-3.5 h-3.5" /> Relative Humidity
                  </span>
                  <p className="text-xl font-black mt-1">{weather.humidity}%</p>
                  <span className="text-[10px] text-amber-200">High fungal pressure</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10">
                  <span className="text-[11px] text-emerald-200 uppercase font-bold tracking-wider flex items-center gap-1.5">
                    <Wind className="w-3.5 h-3.5" /> Wind Speed
                  </span>
                  <p className="text-xl font-black mt-1">{weather.windSpeed} km/h</p>
                  <span className="text-[10px] text-emerald-200">Safe for morning spray</span>
                </div>
              </div>
            </div>
          </div>

          {/* Practical Agricultural Context Advisory */}
          <div className="p-6 rounded-3xl bg-amber-50/70 border border-amber-200 text-amber-950 space-y-2">
            <div className="flex items-center gap-2 text-sm font-bold text-amber-900">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <span>Agro-Climatic Advisory for your Field</span>
            </div>
            <p className="text-xs sm:text-sm text-amber-900 leading-relaxed">
              {weather.advisory}
            </p>
            <div className="pt-2 flex flex-wrap gap-2 text-xs font-semibold">
              <span className="px-3 py-1 rounded-lg bg-white border border-amber-200 text-amber-800">
                🌧️ Rain expected tomorrow — Review irrigation plans
              </span>
              <span className="px-3 py-1 rounded-lg bg-white border border-amber-200 text-amber-800">
                📦 Protect harvested produce in covered sheds
              </span>
            </div>
          </div>

          {/* 5-Day Outlook */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900">5-Day Field Outlook</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {weather.forecast?.map((f, i) => (
                <div key={i} className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50 text-center space-y-1.5">
                  <p className="text-xs font-bold text-slate-700">{f.day}</p>
                  <p className="text-lg font-black text-slate-900">{f.temp}°C</p>
                  <p className="text-[11px] text-slate-500">{f.condition}</p>
                  <div className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    Rain {f.rainProb}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 2. SMART IRRIGATION SECTION */}
      {activeSubTab === 'irrigation' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
            <div className="border-b border-slate-100 pb-4">
              <h3 className="text-lg font-bold text-slate-900">Smart Water & Irrigation Advisor</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Calculates irrigation recommendations based on crop evapotranspiration, growth stage, soil type, and rainfall forecast.
              </p>
            </div>

            {/* Parameter selection */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
                  Crop Type
                </label>
                <select
                  value={selectedCrop}
                  onChange={(e) => setSelectedCrop(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="cotton">Cotton (कपास)</option>
                  <option value="soybean">Soybean (सोयाबीन)</option>
                  <option value="wheat">Wheat (गेहूं)</option>
                  <option value="tomato">Tomato (टमाटर)</option>
                  <option value="rice">Rice (चावल / धान)</option>
                  <option value="sugarcane">Sugarcane (गन्ना)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
                  Crop Stage
                </label>
                <select
                  value={selectedGrowthStage}
                  onChange={(e) => setSelectedGrowthStage(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="vegetative">Vegetative (वानस्पतिक)</option>
                  <option value="flowering">Flowering / Squaring (फूल आने की अवस्था)</option>
                  <option value="boll_fruit">Boll / Fruit Formation (फल बनने की अवस्था)</option>
                  <option value="maturity">Maturity / Ripening (परिपक्वता)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
                  Soil Category
                </label>
                <select
                  value={soilType}
                  onChange={(e) => setSoilType(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="black_cotton">Black Cotton Soil (Heavy Clay)</option>
                  <option value="loam">Medium Loam Soil (दोमट)</option>
                  <option value="sandy">Sandy / Light Alluvial (बलुई)</option>
                </select>
              </div>
            </div>

            {/* Explicit Distinction: Measured Data vs AI Estimated Recommendation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              
              {/* Box 1: Measured Data */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    1. Measured Data
                  </span>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-semibold">
                    Station Telemetry
                  </span>
                </div>
                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Recent 24h Rainfall:</span>
                    <strong className="text-slate-800">4.2 mm</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Ambient Air Temp:</span>
                    <strong className="text-slate-800">{weather.temp}°C</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200">
                    <span>Field Soil Moisture Sensor:</span>
                    <span className="italic text-slate-500">Not configured (Sensor offline)</span>
                  </div>
                </div>
              </div>

              {/* Box 2: AI Estimated Recommendation */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    2. AI Estimated Recommendation
                  </span>
                  <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900 font-bold">
                    Agronomic Estimate
                  </span>
                </div>
                <div className="space-y-1.5 text-xs text-emerald-950">
                  <div className="flex justify-between py-1 border-b border-emerald-200">
                    <span>Recommended Schedule:</span>
                    <strong className="font-bold text-emerald-800">Irrigate in 2 Days</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-emerald-200">
                    <span>Optimal Method:</span>
                    <strong className="font-bold text-emerald-800">Drip (2.5 Hours early morning)</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-emerald-200">
                    <span>Estimated Water Demand:</span>
                    <strong className="font-bold text-emerald-800">~18 - 22 mm / acre</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Agricultural Rationale */}
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-blue-950 text-xs flex items-start gap-3">
              <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Agronomic Reasoning: </span>
                <span>
                  {selectedGrowthStage === 'flowering'
                    ? 'Flowering is moisture-sensitive. Stress now leads to square shedding. However, with rain probability at 65% tomorrow, hold off heavy furrow irrigation until after showers.'
                    : 'Maintain adequate root moisture without waterlogging to support optimal vegetative growth.'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. FERTILIZER & CROP CARE ADVISOR */}
      {activeSubTab === 'fertilizer' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Sprout className="w-5 h-5 text-emerald-600" />
                Balanced Crop Nutrition & General Care Guide
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Responsible nutrient basics and organic care practices. Avoids unsafe chemical over-prescription.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Nutrient Basics */}
              <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Primary Nutrients (NPK)
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  <strong>Nitrogen (N):</strong> Supports green leaf canopy. Avoid excess during cloudy spells to prevent aphid outbreaks.
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  <strong>Phosphorus (P):</strong> Root elongation and vigorous flowering.
                </p>
                <p className="text-xs text-slate-600 leading-relaxed">
                  <strong>Potassium (K):</strong> Disease resistance and drought tolerance.
                </p>
              </div>

              {/* Organic & Preventive Practices */}
              <div className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/50 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                  Organic & Biological Care
                </h4>
                <ul className="text-xs text-emerald-950 space-y-1.5 list-disc list-inside">
                  <li>Incorporate Well-decomposed FYM (Farmyard Manure) @ 4-5 tonnes/acre.</li>
                  <li>Neem Seed Kernel Extract (NSKE 5%) as an eco-friendly pest repellent.</li>
                  <li>Trichoderma viride bio-fungicide for root rot prevention.</li>
                </ul>
              </div>

              {/* Safety & Label Advisory */}
              <div className="p-4 rounded-2xl border border-amber-200 bg-amber-50/60 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  Responsible Safety Practice
                </h4>
                <p className="text-xs text-amber-900 leading-relaxed">
                  Always inspect manufacturer labels for dosage (grams/liter), waiting periods (pre-harvest intervals), and protective gear. Never combine unverified tank mixes.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
