import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginModal } from './components/LoginModal';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { CropDetection } from './components/CropDetection';
import { AnimalHealth } from './components/AnimalHealth';
import { FarmOverview } from './components/FarmOverview';
import { WeatherAdvisory } from './components/WeatherAdvisory';
import { FarmTasks } from './components/FarmTasks';
import { FarmDiary } from './components/FarmDiary';
import { FarmExpenses } from './components/FarmExpenses';
import { KnowledgeHub } from './components/KnowledgeHub';
import { VoiceAssistant } from './components/VoiceAssistant';
import { FollowUpSystem } from './components/FollowUpSystem';
import { FarmerProfile } from './components/FarmerProfile';
import { ScanHistory } from './components/ScanHistory';
import { LocationModal } from './components/LocationModal';
import { SettingsModal } from './components/SettingsModal';
import { Footer } from './components/Footer';
import { HealthScan, Language, NavTab } from './types';
import { collection, addDoc, query, where, onSnapshot, db } from './firebase';
import { Mic } from 'lucide-react';

function MainApp() {
  const { user, userProfile, loading } = useAuth();
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [scans, setScans] = useState<HealthScan[]>([]);
  const [selectedScanDetail, setSelectedScanDetail] = useState<HealthScan | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Modal states
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [settingsInitialTab, setSettingsInitialTab] = useState<'settings' | 'support' | 'privacy' | 'terms'>('settings');

  // Location display
  const [locationName, setLocationName] = useState<string>(
    userProfile?.village && userProfile?.district
      ? `${userProfile.village}, ${userProfile.district}`
      : 'Nagpur Region, MH'
  );
  const [isGPS, setIsGPS] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Update location name if user profile updates
  useEffect(() => {
    if (userProfile?.village && userProfile?.district && !isGPS) {
      setLocationName(`${userProfile.village}, ${userProfile.district}`);
    }
  }, [userProfile, isGPS]);

  // Real-time sync with user's scans in Firestore
  useEffect(() => {
    if (user) {
      try {
        const q = query(
          collection(db, 'healthScans'),
          where('userId', '==', user.uid)
        );
        const unsubscribe = onSnapshot(q, (snapshot) => {
          const loaded: HealthScan[] = [];
          snapshot.forEach((d) => {
            loaded.push({ id: d.id, ...d.data() } as HealthScan);
          });
          // Sort descending by date
          loaded.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          setScans(loaded);
        }, (err) => {
          console.warn('Firestore real-time sync note:', err);
        });
        return () => unsubscribe();
      } catch (err) {
        console.warn('Firestore subscription catch:', err);
      }
    } else {
      setScans([]);
    }
  }, [user]);

  const handleScanComplete = async (newScan: HealthScan) => {
    setScans((prev) => [newScan, ...prev]);
    // Save to Firestore for authenticated user
    if (user) {
      try {
        await addDoc(collection(db, 'healthScans'), {
          ...newScan,
          userId: user.uid,
          timestamp: new Date().toISOString()
        });
      } catch (err) {
        console.warn('Could not persist scan to Firestore:', err);
      }
    }
  };

  const handleOpenSettingsWithTab = (tab?: 'settings' | 'support' | 'privacy' | 'terms') => {
    setSettingsInitialTab(tab || 'settings');
    setIsSettingsModalOpen(true);
  };

  const handleLocationSaved = (newLocation: string, usedGPS: boolean) => {
    setLocationName(newLocation);
    setIsGPS(usedGPS);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="text-center space-y-4 max-w-sm">
          <div className="w-12 h-12 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <div>
            <p className="text-sm font-semibold text-slate-100">Connecting to FarmGuard</p>
            <p className="text-xs text-slate-400 mt-1">Verifying authenticated session</p>
          </div>
        </div>
      </div>
    );
  }

  // Strict route protection: Without login, user cannot access the main page
  if (!user) {
    return <LoginModal />;
  }

  const lang: Language = userProfile?.preferredLanguage || 'en';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased">
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        isOnline={isOnline}
        onOpenVoice={() => setCurrentTab('voice')}
        onOpenSettings={handleOpenSettingsWithTab}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'dashboard' && (
          <Dashboard
            onOpenCropAI={() => setCurrentTab('crop')}
            onOpenAnimalAI={() => setCurrentTab('animal')}
            onOpenProfile={() => setCurrentTab('profile')}
            onNavigate={(tab) => setCurrentTab(tab)}
            scans={scans}
            onOpenScanDetail={(scan) => {
              setSelectedScanDetail(scan);
              setCurrentTab('history');
            }}
            onOpenLocationModal={() => setIsLocationModalOpen(true)}
            locationName={locationName}
            isGPS={isGPS}
          />
        )}

        {currentTab === 'crop' && (
          <CropDetection
            lang={lang}
            onScanComplete={handleScanComplete}
            onBack={() => setCurrentTab('dashboard')}
          />
        )}

        {currentTab === 'animal' && (
          <AnimalHealth
            lang={lang}
            onScanComplete={handleScanComplete}
            onBack={() => setCurrentTab('dashboard')}
          />
        )}

        {currentTab === 'overview' && (
          <FarmOverview
            scans={scans}
            lang={lang}
            onBack={() => setCurrentTab('dashboard')}
            onOpenCropAI={() => setCurrentTab('crop')}
            onOpenAnimalAI={() => setCurrentTab('animal')}
            onOpenTasks={() => setCurrentTab('tasks')}
          />
        )}

        {currentTab === 'weather' && (
          <WeatherAdvisory
            locationName={locationName}
            onBack={() => setCurrentTab('dashboard')}
            onOpenLocationModal={() => setIsLocationModalOpen(true)}
          />
        )}

        {currentTab === 'tasks' && (
          <FarmTasks
            userId={user.uid}
            onBack={() => setCurrentTab('dashboard')}
            onOpenCropAI={() => setCurrentTab('crop')}
          />
        )}

        {currentTab === 'diary' && (
          <FarmDiary
            userId={user.uid}
            onBack={() => setCurrentTab('dashboard')}
          />
        )}

        {currentTab === 'expenses' && (
          <FarmExpenses
            userId={user.uid}
            onBack={() => setCurrentTab('dashboard')}
          />
        )}

        {currentTab === 'knowledge' && (
          <KnowledgeHub
            onBack={() => setCurrentTab('dashboard')}
            onOpenCropAI={() => setCurrentTab('crop')}
            onOpenAnimalAI={() => setCurrentTab('animal')}
          />
        )}

        {currentTab === 'voice' && (
          <VoiceAssistant
            lang={lang}
            onBack={() => setCurrentTab('dashboard')}
            onNavigate={(tab) => setCurrentTab(tab)}
          />
        )}

        {currentTab === 'followup' && (
          <FollowUpSystem
            userId={user.uid}
            onBack={() => setCurrentTab('dashboard')}
            onOpenCropAI={() => setCurrentTab('crop')}
            onOpenAnimalAI={() => setCurrentTab('animal')}
          />
        )}

        {currentTab === 'profile' && (
          <FarmerProfile
            onBack={() => setCurrentTab('dashboard')}
            onOpenLocationModal={() => setIsLocationModalOpen(true)}
            onOpenSettings={handleOpenSettingsWithTab}
          />
        )}

        {currentTab === 'history' && (
          <ScanHistory
            scans={scans}
            onBack={() => setCurrentTab('dashboard')}
            onSelectScan={(scan) => {
              setSelectedScanDetail(scan);
            }}
            onOpenCropAI={() => setCurrentTab('crop')}
            onOpenAnimalAI={() => setCurrentTab('animal')}
          />
        )}
      </main>

      {/* Persistent Floating Quick Voice Assistant Trigger (When not on Voice page) */}
      {currentTab !== 'voice' && (
        <button
          id="floating-voice-assistant-btn"
          type="button"
          onClick={() => setCurrentTab('voice')}
          title="Open Voice Assistant"
          className="fixed bottom-6 right-6 z-30 p-4 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white shadow-xl hover:shadow-2xl transition-all cursor-pointer flex items-center justify-center group"
        >
          <Mic className="w-6 h-6 group-hover:scale-110 transition-transform" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 text-xs font-bold whitespace-nowrap pl-0 group-hover:pl-2">
            Ask Farm AI
          </span>
        </button>
      )}

      {/* Location Modal */}
      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        onLocationSaved={handleLocationSaved}
      />

      {/* Settings, Support, Privacy & Terms Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        initialTab={settingsInitialTab}
      />

      {/* Product Footer */}
      <Footer
        onOpenLegal={handleOpenSettingsWithTab}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
