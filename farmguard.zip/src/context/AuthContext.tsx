import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithPopup, 
  signInWithRedirect, 
  getRedirectResult, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile, 
  sendPasswordResetEmail,
  signOut as fbSignOut 
} from 'firebase/auth';
import { auth, googleProvider, db, doc, getDoc, setDoc } from '../firebase';
import { UserProfile, Language } from '../types';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
  clearError: () => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (name: string, email: string, pass: string, phone: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateUserLanguage: (lang: Language) => Promise<void>;
  updateFarmerProfile: (data: Partial<UserProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Helper to translate raw Firebase error codes to clean farmer-friendly messages
export function getFriendlyAuthErrorMessage(errorCode: string, message?: string): string {
  switch (errorCode) {
    case 'auth/popup-closed-by-user':
      return 'Google sign-in was closed before completion. Please try again.';
    case 'auth/popup-blocked':
      return 'The Google sign-in window was blocked by the browser. Switching to redirect sign-in.';
    case 'auth/cancelled-popup-request':
      return 'Authentication request replaced by a newer request.';
    case 'auth/unauthorized-domain':
      return 'This app domain is not yet authorized in Firebase Console Authentication settings.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Invalid email or password. Please verify your credentials.';
    case 'auth/email-already-in-use':
      return 'An account with this email address already exists. Please sign in with your password.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/missing-password':
      return 'Please provide your account password.';
    case 'auth/too-many-requests':
      return 'Access temporarily blocked due to multiple failed attempts. Please reset your password or try again later.';
    case 'auth/network-request-failed':
      return 'Network connectivity issue. Please check your internet connection.';
    case 'auth/operation-not-allowed':
      return 'This sign-in method is not enabled in the Firebase Authentication Console.';
    default:
      return message || 'Authentication failed. Please verify your credentials and try again.';
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  // Synchronize or create Firestore profile
  const syncUserProfile = async (firebaseUser: User, extraData?: { name?: string; phone?: string }) => {
    try {
      const userRef = doc(db, 'users', firebaseUser.uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        setUserProfile(data);
        await setDoc(userRef, { lastLoginAt: new Date().toISOString() }, { merge: true });
      } else {
        // Create initial profile
        const effectiveName = extraData?.name || firebaseUser.displayName || 'Farmer';
        const effectivePhone = extraData?.phone || firebaseUser.phoneNumber || undefined;
        const newProfile: UserProfile = {
          uid: firebaseUser.uid,
          displayName: effectiveName,
          email: firebaseUser.email || '',
          photoURL: firebaseUser.photoURL || undefined,
          phoneNumber: effectivePhone,
          preferredLanguage: 'en',
          village: 'Kisan Nagar',
          district: 'Nagpur',
          state: 'Maharashtra',
          farmName: `${effectiveName}'s Farm`,
          farmSize: '5 Acres',
          crops: ['Cotton', 'Soybean', 'Wheat'],
          livestock: ['Cow'],
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString()
        };
        await setDoc(userRef, newProfile);
        setUserProfile(newProfile);
      }
    } catch (err: any) {
      console.warn('Firestore profile sync note:', err);
      // Fallback local memory profile so user is not blocked
      const fallbackName = extraData?.name || firebaseUser.displayName || 'Farmer';
      setUserProfile({
        uid: firebaseUser.uid,
        displayName: fallbackName,
        email: firebaseUser.email || '',
        photoURL: firebaseUser.photoURL || undefined,
        phoneNumber: extraData?.phone || firebaseUser.phoneNumber || undefined,
        preferredLanguage: 'en',
        village: 'Kisan Nagar',
        district: 'Nagpur',
        state: 'Maharashtra',
        farmName: `${fallbackName}'s Farm`,
        farmSize: '5 Acres',
        crops: ['Cotton', 'Wheat'],
        livestock: ['Cow']
      });
    }
  };

  // Listen for redirect results on page load
  useEffect(() => {
    let mounted = true;

    getRedirectResult(auth)
      .then(async (result) => {
        if (!mounted) return;
        if (result && result.user) {
          setUser(result.user);
          await syncUserProfile(result.user);
        }
      })
      .catch((err) => {
        if (!mounted) return;
        console.error('Firebase redirect auth error:', err);
        setError(getFriendlyAuthErrorMessage(err.code, err.message));
      });

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (!mounted) return;
      setUser(currentUser);
      if (currentUser) {
        await syncUserProfile(currentUser);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  // Official Firebase Google Authentication Flow
  const signInWithGoogle = async () => {
    setError(null);
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result && result.user) {
        setUser(result.user);
        await syncUserProfile(result.user);
      }
    } catch (err: any) {
      console.error('Google Sign In Error:', err);
      if (err.code === 'auth/popup-blocked' || err.code === 'auth/cancelled-popup-request') {
        try {
          await signInWithRedirect(auth, googleProvider);
          return;
        } catch (redirectErr: any) {
          setError(getFriendlyAuthErrorMessage(redirectErr.code, redirectErr.message));
        }
      } else {
        setError(getFriendlyAuthErrorMessage(err.code, err.message));
      }
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const result = await signInWithEmailAndPassword(auth, email.trim(), pass);
      if (result && result.user) {
        setUser(result.user);
        await syncUserProfile(result.user);
      }
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err.code, err.message));
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signUpWithEmail = async (name: string, email: string, pass: string, phone: string) => {
    setError(null);
    setLoading(true);
    try {
      const trimmedName = name.trim();
      const trimmedEmail = email.trim();
      const trimmedPhone = phone.trim();

      const result = await createUserWithEmailAndPassword(auth, trimmedEmail, pass);
      if (result && result.user) {
        await updateProfile(result.user, { displayName: trimmedName });
        const updatedUser = { ...result.user, displayName: trimmedName } as User;
        setUser(updatedUser);

        await syncUserProfile(result.user, { name: trimmedName, phone: trimmedPhone });
      }
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err.code, err.message));
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email.trim());
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err.code, err.message));
      throw err;
    }
  };

  const signOut = async () => {
    setError(null);
    try {
      await fbSignOut(auth);
      setUser(null);
      setUserProfile(null);
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err.code, err.message));
    }
  };

  const updateUserLanguage = async (lang: Language) => {
    if (userProfile) {
      const updated = { ...userProfile, preferredLanguage: lang };
      setUserProfile(updated);
      if (user) {
        try {
          await setDoc(doc(db, 'users', user.uid), { preferredLanguage: lang }, { merge: true });
        } catch (e) {
          console.warn('Could not save language to Firestore', e);
        }
      }
    }
  };

  const updateFarmerProfile = async (data: Partial<UserProfile>) => {
    if (!userProfile) return;
    const updated = { ...userProfile, ...data };
    setUserProfile(updated);
    if (user) {
      try {
        await setDoc(doc(db, 'users', user.uid), data, { merge: true });
      } catch (e) {
        console.warn('Could not update profile in Firestore', e);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        error,
        clearError,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        resetPassword,
        signOut,
        updateUserLanguage,
        updateFarmerProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
