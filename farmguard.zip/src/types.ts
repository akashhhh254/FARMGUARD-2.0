export type Language = 'en' | 'hi' | 'mr';

export type NavTab = 
  | 'dashboard'
  | 'crop'
  | 'animal'
  | 'overview'
  | 'weather'
  | 'irrigation'
  | 'tasks'
  | 'history'
  | 'alerts'
  | 'diary'
  | 'expenses'
  | 'knowledge'
  | 'voice'
  | 'profile'
  | 'settings'
  | 'support'
  | 'followup';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  phoneNumber?: string;
  preferredLanguage: Language;
  village?: string;
  district?: string;
  state?: string;
  country?: string;
  farmName?: string;
  farmSize?: string;
  crops?: string[];
  livestock?: string[];
  fields?: string;
  soilInformation?: string;
  waterSource?: string;
  createdAt?: any;
  lastLoginAt?: any;
}

export interface HealthScan {
  id: string;
  userId: string;
  type: 'crop' | 'livestock';
  targetName: string; // Crop name or Livestock type
  date: string;
  imageUrl?: string;
  diseaseOrCondition: string;
  confidence: number; // e.g. 0.92
  severity: 'healthy' | 'low' | 'moderate' | 'high' | 'critical';
  indicators: string[];
  causes?: string[];
  immediateActions: string[];
  prevention: string[];
  expertAdvice: string;
  isUrgent: boolean;
  symptomsReported?: string[];
  notes?: string;
  stage?: string;
  aiExplanation?: {
    what: string;
    why: string;
    howConfident: string;
    whatNext: string;
  };
}

export interface FollowUpRecord {
  id: string;
  userId: string;
  originalScanId: string;
  targetName: string;
  type: 'crop' | 'livestock';
  scheduledDate: string;
  completed: boolean;
  notes?: string;
  originalCondition: string;
  originalSeverity: string;
  followUpScanId?: string;
  currentCondition?: string;
  currentSeverity?: string;
  statusChange?: 'improved' | 'stable' | 'worsened' | 'pending';
}

export interface WeatherData {
  temp: number;
  condition: string;
  humidity: number;
  rainfallRisk: string;
  windSpeed: number;
  advisory: string;
  locationName: string;
  isLive: boolean;
  forecast?: Array<{
    day: string;
    temp: number;
    condition: string;
    rainProb: number;
  }>;
}

export interface FarmExpense {
  id: string;
  userId: string;
  title: string;
  type: 'income' | 'expense';
  category: 
    | 'Seeds'
    | 'Fertilizer'
    | 'Crop protection'
    | 'Labour'
    | 'Irrigation'
    | 'Equipment'
    | 'Animal feed'
    | 'Veterinary expenses'
    | 'Transport'
    | 'Crop sales'
    | 'Livestock sales'
    | 'Other';
  amount: number;
  date: string;
  notes?: string;
}

export interface FarmAlert {
  id: string;
  title: string;
  message: string;
  type: 'danger' | 'warning' | 'info' | 'success';
  priority: 'low' | 'medium' | 'high';
  category: 'crop' | 'livestock' | 'weather' | 'irrigation' | 'tasks' | 'followup';
  timestamp: string;
  target?: string;
  actionRequired?: string;
}

export interface FarmTask {
  id: string;
  userId: string;
  title: string;
  category: 'irrigation' | 'fertilizer' | 'inspection' | 'vaccination' | 'harvest' | 'custom';
  dueDate: string;
  completed: boolean;
  priority?: 'low' | 'medium' | 'high';
  notes?: string;
}

export interface FarmDiaryEntry {
  id: string;
  userId: string;
  date: string;
  category: 'crop' | 'livestock' | 'disease' | 'irrigation' | 'fertilizer' | 'weather' | 'harvest' | 'expense' | 'note';
  title: string;
  description: string;
  imageUrl?: string;
}

export interface MarketPrice {
  crop: string;
  market: string;
  pricePerQuintal: number;
  trend: 'up' | 'down' | 'stable';
  date: string;
}

export interface KnowledgeArticle {
  id: string;
  category: 'Crop Diseases' | 'Pest Management' | 'Crop Care' | 'Livestock Health' | 'Soil Health' | 'Water Management' | 'Weather Preparedness' | 'Farm Safety';
  title: { en: string; hi: string; mr: string };
  summary: { en: string; hi: string; mr: string };
  steps: { en: string[]; hi: string[]; mr: string[] };
  readTime: string;
  icon: string;
}

export interface SupportContact {
  id: string;
  name: string;
  category: 'helpline' | 'kvk' | 'veterinary' | 'soil';
  phone: string;
  address: string;
  timing: string;
  verified: boolean;
  notes: string;
}
