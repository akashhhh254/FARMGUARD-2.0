import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  updateDoc, 
  doc, 
  db 
} from '../firebase';
import { 
  FarmTask, 
  FarmExpense, 
  FarmDiaryEntry, 
  FollowUpRecord, 
  FarmAlert 
} from '../types';

// Storage keys
const TASK_KEY = 'farmguard_tasks_';
const EXPENSE_KEY = 'farmguard_expenses_';
const DIARY_KEY = 'farmguard_diary_';
const FOLLOWUP_KEY = 'farmguard_followups_';

// Default initial tasks for a farmer
export const DEFAULT_TASKS: Omit<FarmTask, 'id' | 'userId'>[] = [
  {
    title: 'Morning Crop Inspection (Cotton & Soybean field)',
    category: 'inspection',
    dueDate: new Date().toISOString().split('T')[0],
    completed: false,
    priority: 'high',
    notes: 'Look for leaf curl symptoms, whitefly presence on underside of leaves.'
  },
  {
    title: 'Check Cow Herd & Clean Stall Bedding',
    category: 'vaccination',
    dueDate: new Date().toISOString().split('T')[0],
    completed: true,
    priority: 'medium',
    notes: 'Inspect udder health during morning milking; apply lime powder in damp areas.'
  },
  {
    title: 'Drip Irrigation Schedule (Zone 1 - 2 Hours)',
    category: 'irrigation',
    dueDate: new Date().toISOString().split('T')[0],
    completed: false,
    priority: 'high',
    notes: 'Scheduled for 4:00 PM before expected dry evening winds.'
  },
  {
    title: 'FMD Vaccination Booster for Cattle',
    category: 'vaccination',
    dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0],
    completed: false,
    priority: 'high',
    notes: 'Veterinary assistant Dr. Sharma visiting village on Thursday.'
  }
];

// Default initial diary entries
export const DEFAULT_DIARY_ENTRIES: Omit<FarmDiaryEntry, 'id' | 'userId'>[] = [
  {
    date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
    category: 'crop',
    title: 'Weeding & Soil Aeration in North Field',
    description: 'Completed manual inter-culture weeding in 2 acres of Cotton. Soil moisture is moderate.',
    imageUrl: 'https://images.unsplash.com/photo-1592417817098-8f3d6910985c?w=400&auto=format&fit=crop&q=80'
  },
  {
    date: new Date(Date.now() - 86400000 * 3).toISOString().split('T')[0],
    category: 'livestock',
    title: 'Cattle Feed Replenishment & Mineral Mixture',
    description: 'Procured 4 bags of concentrated cattle feed and 5kg mineral mixture with calcium supplements.',
    imageUrl: 'https://images.unsplash.com/photo-1546445317-29f4545e9d53?w=400&auto=format&fit=crop&q=80'
  }
];

// Default initial expenses
export const DEFAULT_EXPENSES: Omit<FarmExpense, 'id' | 'userId'>[] = [
  {
    title: 'Cotton Harvest Revenue',
    type: 'income',
    category: 'Crop sales',
    amount: 32000,
    date: new Date(Date.now() - 86400000 * 5).toISOString().split('T')[0],
    notes: 'Sold 4 quintals of early harvest cotton at APMC market.'
  },
  {
    title: 'Hybrid Seed Purchase',
    type: 'expense',
    category: 'Seeds',
    amount: 4500,
    date: new Date(Date.now() - 86400000 * 8).toISOString().split('T')[0],
    notes: 'Certified BG-II cotton seed packets.'
  },
  {
    title: 'Weeding Labour Wages',
    type: 'expense',
    category: 'Labour',
    amount: 6000,
    date: new Date(Date.now() - 86400000 * 4).toISOString().split('T')[0],
    notes: 'Field weeding and channel clearing labour.'
  },
  {
    title: 'Livestock Fodder & Feed',
    type: 'expense',
    category: 'Animal feed',
    amount: 3200,
    date: new Date(Date.now() - 86400000 * 2).toISOString().split('T')[0],
    notes: 'Cattle concentrate feed & dry fodder.'
  }
];

// Default Smart Alerts
export const DEFAULT_ALERTS: FarmAlert[] = [
  {
    id: 'alert-weather-1',
    title: 'Rain Forecast Alert',
    message: 'Scattered showers expected in next 36-48h. Review irrigation plans and protect harvested produce.',
    type: 'info',
    priority: 'medium',
    category: 'weather',
    timestamp: 'Today, 06:30 AM',
    actionRequired: 'Pause drip irrigation cycle'
  },
  {
    id: 'alert-pest-2',
    title: 'Regional Whitefly Surge Reported',
    message: 'Neighboring taluka reported early whitefly vector activity on young cotton and chili plants.',
    type: 'warning',
    priority: 'high',
    category: 'crop',
    timestamp: 'Yesterday',
    actionRequired: 'Inspect leaf undersides & place yellow sticky traps'
  },
  {
    id: 'alert-vet-3',
    title: 'Livestock Deworming Window Open',
    message: 'Pre-monsoon deworming is due for small ruminants and calves.',
    type: 'warning',
    priority: 'medium',
    category: 'livestock',
    timestamp: '2 days ago',
    actionRequired: 'Schedule veterinary visit'
  }
];

// Local storage helpers with fallback
export function getLocalItems<T>(keyPrefix: string, userId: string, defaultItems: any[] = []): T[] {
  try {
    const raw = localStorage.getItem(`${keyPrefix}${userId}`);
    if (!raw) {
      const initialized = defaultItems.map((item, idx) => ({
        ...item,
        id: `${keyPrefix.replace(/[^a-z]/gi, '')}-${idx + 1}`,
        userId
      }));
      localStorage.setItem(`${keyPrefix}${userId}`, JSON.stringify(initialized));
      return initialized;
    }
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveLocalItems<T>(keyPrefix: string, userId: string, items: T[]): void {
  try {
    localStorage.setItem(`${keyPrefix}${userId}`, JSON.stringify(items));
  } catch (e) {
    console.warn('LocalStorage save error:', e);
  }
}

// Tasks API
export async function fetchUserTasks(userId: string): Promise<FarmTask[]> {
  const local = getLocalItems<FarmTask>(TASK_KEY, userId, DEFAULT_TASKS);
  if (!navigator.onLine) return local;

  try {
    const q = query(collection(db, 'farmTasks'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const serverItems: FarmTask[] = [];
      snap.forEach((d) => serverItems.push({ id: d.id, ...d.data() } as FarmTask));
      saveLocalItems(TASK_KEY, userId, serverItems);
      return serverItems;
    }
  } catch (err) {
    console.warn('Firestore tasks sync fallback to local cache:', err);
  }
  return local;
}

export async function saveUserTask(userId: string, task: Omit<FarmTask, 'id' | 'userId'>): Promise<FarmTask> {
  const newTask: FarmTask = {
    ...task,
    id: 'task-' + Date.now(),
    userId
  };

  const existing = getLocalItems<FarmTask>(TASK_KEY, userId, DEFAULT_TASKS);
  const updated = [newTask, ...existing];
  saveLocalItems(TASK_KEY, userId, updated);

  if (navigator.onLine) {
    try {
      const ref = await addDoc(collection(db, 'farmTasks'), newTask);
      newTask.id = ref.id;
    } catch (e) {
      console.warn('Task saved to local queue (sync pending):', e);
    }
  }
  return newTask;
}

export async function toggleUserTask(userId: string, taskId: string, completed: boolean): Promise<void> {
  const existing = getLocalItems<FarmTask>(TASK_KEY, userId, DEFAULT_TASKS);
  const updated = existing.map((t) => (t.id === taskId ? { ...t, completed } : t));
  saveLocalItems(TASK_KEY, userId, updated);

  if (navigator.onLine) {
    try {
      await updateDoc(doc(db, 'farmTasks', taskId), { completed });
    } catch (e) {
      // Ignored for offline
    }
  }
}

// Expenses API
export async function fetchUserExpenses(userId: string): Promise<FarmExpense[]> {
  const local = getLocalItems<FarmExpense>(EXPENSE_KEY, userId, DEFAULT_EXPENSES);
  if (!navigator.onLine) return local;

  try {
    const q = query(collection(db, 'farmExpenses'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const serverItems: FarmExpense[] = [];
      snap.forEach((d) => serverItems.push({ id: d.id, ...d.data() } as FarmExpense));
      saveLocalItems(EXPENSE_KEY, userId, serverItems);
      return serverItems;
    }
  } catch (err) {
    console.warn('Firestore expenses sync fallback:', err);
  }
  return local;
}

export async function saveUserExpense(userId: string, expense: Omit<FarmExpense, 'id' | 'userId'>): Promise<FarmExpense> {
  const newExp: FarmExpense = {
    ...expense,
    id: 'exp-' + Date.now(),
    userId
  };

  const existing = getLocalItems<FarmExpense>(EXPENSE_KEY, userId, DEFAULT_EXPENSES);
  const updated = [newExp, ...existing];
  saveLocalItems(EXPENSE_KEY, userId, updated);

  if (navigator.onLine) {
    try {
      const ref = await addDoc(collection(db, 'farmExpenses'), newExp);
      newExp.id = ref.id;
    } catch (e) {
      console.warn('Expense saved to offline cache:', e);
    }
  }
  return newExp;
}

// Diary API
export async function fetchUserDiary(userId: string): Promise<FarmDiaryEntry[]> {
  const local = getLocalItems<FarmDiaryEntry>(DIARY_KEY, userId, DEFAULT_DIARY_ENTRIES);
  if (!navigator.onLine) return local;

  try {
    const q = query(collection(db, 'farmDiary'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const serverItems: FarmDiaryEntry[] = [];
      snap.forEach((d) => serverItems.push({ id: d.id, ...d.data() } as FarmDiaryEntry));
      saveLocalItems(DIARY_KEY, userId, serverItems);
      return serverItems;
    }
  } catch (err) {
    console.warn('Firestore diary sync fallback:', err);
  }
  return local;
}

export async function saveUserDiaryEntry(userId: string, entry: Omit<FarmDiaryEntry, 'id' | 'userId'>): Promise<FarmDiaryEntry> {
  const newEntry: FarmDiaryEntry = {
    ...entry,
    id: 'diary-' + Date.now(),
    userId
  };

  const existing = getLocalItems<FarmDiaryEntry>(DIARY_KEY, userId, DEFAULT_DIARY_ENTRIES);
  const updated = [newEntry, ...existing];
  saveLocalItems(DIARY_KEY, userId, updated);

  if (navigator.onLine) {
    try {
      const ref = await addDoc(collection(db, 'farmDiary'), newEntry);
      newEntry.id = ref.id;
    } catch (e) {
      console.warn('Diary entry saved locally:', e);
    }
  }
  return newEntry;
}

// Follow-Ups API
export async function fetchUserFollowUps(userId: string): Promise<FollowUpRecord[]> {
  const local = getLocalItems<FollowUpRecord>(FOLLOWUP_KEY, userId, []);
  return local;
}

export async function saveFollowUp(userId: string, followUp: Omit<FollowUpRecord, 'id' | 'userId'>): Promise<FollowUpRecord> {
  const newFollowUp: FollowUpRecord = {
    ...followUp,
    id: 'followup-' + Date.now(),
    userId
  };

  const existing = getLocalItems<FollowUpRecord>(FOLLOWUP_KEY, userId, []);
  const updated = [newFollowUp, ...existing];
  saveLocalItems(FOLLOWUP_KEY, userId, updated);

  if (navigator.onLine) {
    try {
      await addDoc(collection(db, 'followUps'), newFollowUp);
    } catch (e) {
      console.warn('Follow-up saved locally:', e);
    }
  }
  return newFollowUp;
}
