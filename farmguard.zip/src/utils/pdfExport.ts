import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { HealthScan, UserProfile } from '../types';

export interface ReportOptions {
  farmerName?: string;
  farmName?: string;
  location?: string;
  consultantName?: string;
  notes?: string;
  filterType?: 'all' | 'crop' | 'livestock' | 'high_risk';
}

export function generateHealthSummaryPDF(
  scans: HealthScan[],
  profile?: UserProfile | null,
  options?: ReportOptions
) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const primaryColor = [16, 128, 67]; // Forest Emerald #108043
  const darkTextColor = [30, 41, 59]; // Slate 800
  const lightBgColor = [248, 250, 252]; // Slate 50

  const farmerName = options?.farmerName || profile?.displayName || 'Farmer';
  const farmName = options?.farmName || profile?.farmName || 'Farm Holding';
  const location = options?.location || (profile?.district ? `${profile.village ? profile.village + ', ' : ''}${profile.district}, ${profile.state || 'India'}` : 'Agricultural Zone, India');
  const consultant = options?.consultantName || 'Agricultural Extension Consultant / Veterinary Officer';
  const farmSize = profile?.farmSize || 'Not specified';
  const generatedDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  // Filter scans if requested
  const filteredScans = scans.filter((s) => {
    if (options?.filterType === 'crop') return s.type === 'crop';
    if (options?.filterType === 'livestock') return s.type === 'livestock';
    if (options?.filterType === 'high_risk') return s.severity === 'critical' || s.severity === 'high';
    return true;
  });

  const totalScans = filteredScans.length;
  const cropCount = filteredScans.filter((s) => s.type === 'crop').length;
  const animalCount = filteredScans.filter((s) => s.type === 'livestock').length;
  const highRiskCount = filteredScans.filter((s) => s.severity === 'critical' || s.severity === 'high').length;
  const moderateCount = filteredScans.filter((s) => s.severity === 'moderate').length;
  const healthyCount = filteredScans.filter((s) => s.severity === 'healthy' || s.severity === 'low').length;

  // --- HEADER SECTION ---
  // Top green banner
  doc.setFillColor(16, 128, 67);
  doc.rect(0, 0, 210, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('FARM GUARD', 14, 12);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Agricultural Health & Livestock Disease Intelligence Platform', 14, 18);

  doc.setFontSize(8);
  doc.text('OFFICIAL FARM AUDIT REPORT', 196, 12, { align: 'right' });
  doc.text(`Generated: ${generatedDate}`, 196, 18, { align: 'right' });

  // Title
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('FARM HEALTH ASSESSMENT & SCAN AUDIT SUMMARY', 14, 34);

  // Metadata Grid Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 38, 182, 28, 2, 2, 'FD');

  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'bold');
  doc.text('Farmer / Landholder:', 18, 45);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`${farmerName} (${farmName})`, 56, 45);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Farm Location & Size:', 18, 52);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`${location} | Holding: ${farmSize}`, 56, 52);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Consultant / Recipient:', 18, 59);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(consultant, 56, 59);

  // --- STATISTICAL SUMMARY CARDS (4 Mini Cards) ---
  const startY = 71;
  const cardW = 43;
  const cardH = 18;
  const gap = 3.3;

  // Card 1: Total Scans
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(14, startY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL ASSESSMENTS', 18, startY + 6);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`${totalScans}`, 18, startY + 14);

  // Card 2: Crops vs Animals
  doc.setFillColor(236, 253, 245);
  doc.roundedRect(14 + (cardW + gap) * 1, startY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(4, 120, 87);
  doc.text('CROPS / LIVESTOCK', 18 + (cardW + gap) * 1, startY + 6);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(6, 95, 70);
  doc.text(`${cropCount} / ${animalCount}`, 18 + (cardW + gap) * 1, startY + 14);

  // Card 3: Healthy / Controlled
  doc.setFillColor(239, 246, 255);
  doc.roundedRect(14 + (cardW + gap) * 2, startY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(29, 78, 216);
  doc.text('STABLE / MILD', 18 + (cardW + gap) * 2, startY + 6);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 64, 175);
  doc.text(`${healthyCount}`, 18 + (cardW + gap) * 2, startY + 14);

  // Card 4: High Risk / Attention
  doc.setFillColor(254, 242, 242);
  doc.roundedRect(14 + (cardW + gap) * 3, startY, cardW, cardH, 1.5, 1.5, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(185, 28, 28);
  doc.text('HIGH RISK ACTIVE', 18 + (cardW + gap) * 3, startY + 6);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(153, 27, 27);
  doc.text(`${highRiskCount}`, 18 + (cardW + gap) * 3, startY + 14);

  // Optional Farmer's Special Notes / Consultant Question
  let currentY = 94;
  if (options?.notes && options.notes.trim().length > 0) {
    doc.setFillColor(254, 252, 232);
    doc.setDrawColor(254, 240, 138);
    doc.roundedRect(14, currentY, 182, 14, 1.5, 1.5, 'FD');
    doc.setFontSize(8);
    doc.setTextColor(133, 77, 14);
    doc.setFont('helvetica', 'bold');
    doc.text('FARMER NOTES & INQUIRY FOR CONSULTANT:', 18, currentY + 5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(113, 63, 18);
    const splitNotes = doc.splitTextToSize(options.notes, 174);
    doc.text(splitNotes, 18, currentY + 10);
    currentY += 18;
  }

  // --- SCAN HISTORY DATA TABLE ---
  const tableData = filteredScans.map((scan, index) => {
    const formattedDate = new Date(scan.date).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: '2-digit'
    });
    const typeLabel = scan.type === 'crop' ? 'Crop' : 'Livestock';
    const actions = (scan.immediateActions && scan.immediateActions.length > 0)
      ? scan.immediateActions.slice(0, 2).join('; ')
      : scan.expertAdvice || 'Continue regular monitoring and good sanitation.';
    const conf = scan.confidence ? `${Math.round(scan.confidence * 100)}%` : '90%';

    return [
      String(index + 1),
      formattedDate,
      `${typeLabel}: ${scan.targetName}`,
      scan.diseaseOrCondition,
      scan.severity.toUpperCase(),
      conf,
      actions
    ];
  });

  autoTable(doc, {
    startY: currentY,
    head: [['#', 'Date', 'Target / Subject', 'Identified Condition', 'Severity', 'Conf.', 'Recommended Advisory / Action']],
    body: tableData.length > 0 ? tableData : [['-', '-', 'No records', 'No health scans logged yet', 'STABLE', '-', 'Run initial crop or livestock scan']],
    theme: 'grid',
    headStyles: {
      fillColor: [16, 128, 67],
      textColor: [255, 255, 255],
      fontSize: 8,
      fontStyle: 'bold',
      halign: 'left',
      cellPadding: 2.5
    },
    styles: {
      fontSize: 7.5,
      textColor: [30, 41, 59],
      cellPadding: 2,
      overflow: 'linebreak',
      valign: 'middle'
    },
    columnStyles: {
      0: { cellWidth: 8, halign: 'center' },
      1: { cellWidth: 18 },
      2: { cellWidth: 32 },
      3: { cellWidth: 38 },
      4: { cellWidth: 18, fontStyle: 'bold' },
      5: { cellWidth: 13, halign: 'center' },
      6: { cellWidth: 55 }
    },
    didParseCell: (data) => {
      // Color-code severity column
      if (data.section === 'body' && data.column.index === 4) {
        const val = String(data.cell.raw).toUpperCase();
        if (val.includes('CRITICAL') || val.includes('HIGH')) {
          data.cell.styles.textColor = [185, 28, 28]; // Red
        } else if (val.includes('MODERATE')) {
          data.cell.styles.textColor = [217, 119, 6]; // Amber
        } else {
          data.cell.styles.textColor = [5, 150, 105]; // Green
        }
      }
    }
  });

  // Get position after table
  const finalY = (doc as any).lastAutoTable?.finalY || currentY + 60;

  // --- CONSULTANT CLINICAL REVIEW & VERIFICATION FOOTER ---
  const signY = Math.min(finalY + 12, 260);

  // If table went too close to bottom, add a new page for signature and helpline
  if (signY > 250) {
    doc.addPage();
  }

  const reviewY = signY > 250 ? 20 : signY;

  // Review section box
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(250, 250, 250);
  doc.roundedRect(14, reviewY, 182, 24, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('CONSULTANT / EXTENSION OFFICER REVIEW & SIGN-OFF:', 18, reviewY + 6);

  doc.setFont('helvetica', 'normal');
  doc.text('Comments & Recommendations: ________________________________________________________________', 18, reviewY + 12);
  doc.text('Consultant Signature & Seal: ______________________      Follow-up Date: ______________________', 18, reviewY + 19);

  // Footer / Emergency numbers
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text('Government Emergency Helplines: Kisan Call Center 1800-180-1551 (Toll-free) | Animal Health & Vet Ambulance 1962', 14, 290);
  doc.text('Page 1 of 1 • Generated via FarmGuard AI Agricultural Support', 196, 290, { align: 'right' });

  // Save the PDF
  const cleanFarmName = farmName.replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `FarmGuard_Health_Report_${cleanFarmName}_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(filename);
}
